import React, { useState } from 'react';
import { ChevronDown, ChevronRight, CheckCircle2, Circle, Home, Users, Briefcase, Heart, Building2, Shield, UserCog, Store, Menu } from 'lucide-react';

interface Page {
  name: string;
  path: string;
  component: string;
  exists: boolean;
  route: string;
}

interface RoleSection {
  role: string;
  icon: any;
  total: number;
  created: number;
  percentage: number;
  status: 'complete' | 'high' | 'medium' | 'low' | 'none';
  pages: Page[];
}

interface TableOfContentsProps {
  onNavigate?: (page: string) => void;
  onCreatePage?: (page: Page) => void;
}

export default function TableOfContents({ onNavigate, onCreatePage }: TableOfContentsProps) {
  const [expandedSections, setExpandedSections] = useState<string[]>(['shared']);
  const [selectedPage, setSelectedPage] = useState<string>('');

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const sections: RoleSection[] = [
    {
      role: 'Shared / Authentication',
      icon: Home,
      total: 13,
      created: 13,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Landing Page', path: '/components/shared/LandingPage.tsx', component: 'LandingPage', exists: true, route: 'landing' },
        { name: 'Login', path: '/components/auth/Login.tsx', component: 'Login', exists: true, route: 'login' },
        { name: 'Role Selection', path: '/components/auth/RoleSelection.tsx', component: 'RoleSelection', exists: true, route: 'role-selection' },
        { name: 'MFA Verification', path: '/components/shared/MFAVerification.tsx', component: 'MFAVerification', exists: true, route: 'mfa-verification' },
        { name: 'MFA Setup ➕', path: '/components/shared/MFASetup.tsx', component: 'MFASetup', exists: true, route: 'mfa-setup' },
        { name: 'Password Reset - Step 1', path: '/components/shared/PasswordReset.tsx', component: 'PasswordReset', exists: true, route: 'password-reset' },
        { name: 'Password Reset - Step 2', path: '/components/shared/PasswordResetStep2.tsx', component: 'PasswordResetStep2', exists: true, route: 'password-reset-step-2' },
        { name: 'Password Reset - Step 3', path: '/components/shared/PasswordResetStep3.tsx', component: 'PasswordResetStep3', exists: true, route: 'password-reset-step-3' },
        { name: 'Password Reset - Success', path: '/components/shared/PasswordResetSuccess.tsx', component: 'PasswordResetSuccess', exists: true, route: 'password-reset-success' },
        { name: 'Terms & Conditions', path: '/components/shared/TermsAndConditions.tsx', component: 'TermsAndConditions', exists: true, route: 'terms-and-conditions' },
        { name: 'Privacy Policy', path: '/components/shared/PrivacyPolicy.tsx', component: 'PrivacyPolicy', exists: true, route: 'privacy-policy' },
        { name: '404 Not Found', path: '/components/shared/NotFound.tsx', component: 'NotFound', exists: true, route: 'not-found' },
        { name: 'Offline State', path: '/components/shared/OfflineState.tsx', component: 'OfflineState', exists: true, route: 'offline-state' },
      ]
    },
    {
      role: 'Guardian',
      icon: Users,
      total: 26,
      created: 26,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Registration Step 1', path: '/components/guardian/GuardianRegistration.tsx', component: 'GuardianRegistration', exists: true, route: 'guardian-registration-1' },
        { name: 'Registration Step 2', path: '/components/guardian/GuardianRegistrationStep2.tsx', component: 'GuardianRegistrationStep2', exists: true, route: 'guardian-registration-2' },
        { name: 'Registration Step 3', path: '/components/guardian/GuardianRegistrationStep3.tsx', component: 'GuardianRegistrationStep3', exists: true, route: 'guardian-registration-3' },
        { name: 'Dashboard', path: '/components/guardian/GuardianDashboard.tsx', component: 'GuardianDashboard', exists: true, route: 'guardian-home' },
        { name: 'Add Patient', path: '/components/guardian/AddPatient.tsx', component: 'AddPatient', exists: true, route: 'guardian-add-patient' },
        { name: 'My Patients', path: '/components/guardian/MyPatients.tsx', component: 'MyPatients', exists: true, route: 'guardian-patients' },
        { name: 'Patient Detail', path: '/components/guardian/PatientDetail.tsx', component: 'PatientDetail', exists: true, route: 'guardian-patient-detail' },
        { name: 'Edit Patient ➕', path: '/components/guardian/EditPatient.tsx', component: 'EditPatient', exists: true, route: 'guardian-edit-patient' },
        { name: 'Patient Health Records', path: '/components/guardian/PatientHealthRecords.tsx', component: 'PatientHealthRecords', exists: true, route: 'guardian-health-records' },
        { name: 'Prescription Upload (AI OCR)', path: '/components/guardian/PrescriptionUpload.tsx', component: 'PrescriptionUpload', exists: true, route: 'guardian-prescription-upload' },
        { name: 'Browse Packages', path: '/components/guardian/BrowsePackages.tsx', component: 'BrowsePackages', exists: true, route: 'guardian-browse-packages' },
        { name: 'Package Filters', path: '/components/guardian/PackageFilters.tsx', component: 'PackageFilters', exists: true, route: 'guardian-package-filters' },
        { name: 'Package Detail', path: '/components/guardian/PackageDetail.tsx', component: 'PackageDetail', exists: true, route: 'guardian-package-detail' },
        { name: 'Negotiation - Send Counter-Offer', path: '/components/guardian/NegotiationSendOffer.tsx', component: 'NegotiationSendOffer', exists: true, route: 'guardian-negotiation' },
        { name: 'Negotiation - Wait for Response', path: '/components/guardian/NegotiationWaiting.tsx', component: 'NegotiationWaiting', exists: true, route: 'guardian-negotiation-waiting' },
        { name: 'Negotiation - Review Agency Response', path: '/components/guardian/NegotiationReview.tsx', component: 'NegotiationReview', exists: true, route: 'guardian-negotiation-review' },
        { name: 'Active Jobs List', path: '/components/guardian/ActiveJobs.tsx', component: 'ActiveJobs', exists: true, route: 'guardian-jobs' },
        { name: 'Job Detail', path: '/components/guardian/JobDetail.tsx', component: 'JobDetail', exists: true, route: 'guardian-job-detail' },
        { name: 'Messages Inbox', path: '/components/guardian/MessagesInbox.tsx', component: 'GuardianMessagesInbox', exists: true, route: 'guardian-messages' },
        { name: 'Chat Screen', path: '/components/guardian/ChatScreen.tsx', component: 'GuardianChatScreen', exists: true, route: 'guardian-chat' },
        { name: 'Billing - Agency Invoices', path: '/components/guardian/BillingInvoices.tsx', component: 'GuardianBillingInvoices', exists: true, route: 'guardian-billing' },
        { name: 'Billing - Platform Invoices', path: '/components/guardian/BillingPlatform.tsx', component: 'GuardianBillingPlatform', exists: true, route: 'guardian-billing-platform' },
        { name: 'Payment Reminder (Day 3)', path: '/components/guardian/PaymentReminder.tsx', component: 'GuardianPaymentReminder', exists: true, route: 'guardian-payment-reminder' },
        { name: 'Payment Warning (Day 5)', path: '/components/guardian/PaymentWarning.tsx', component: 'GuardianPaymentWarning', exists: true, route: 'guardian-payment-warning' },
        { name: 'Payment Final Warning (Day 6)', path: '/components/guardian/PaymentFinalWarning.tsx', component: 'GuardianPaymentFinalWarning', exists: true, route: 'guardian-payment-final-warning' },
        { name: 'Account Locked (Day 7+)', path: '/components/guardian/AccountLocked.tsx', component: 'GuardianAccountLocked', exists: true, route: 'guardian-account-locked' },
        { name: 'Settings ➕', path: '/components/guardian/GuardianSettings.tsx', component: 'GuardianSettings', exists: true, route: 'guardian-settings' },
      ]
    },
    {
      role: 'Agency Admin',
      icon: Building2,
      total: 24,
      created: 24,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Registration Step 1', path: '/components/agency/AgencyRegistration.tsx', component: 'AgencyRegistration', exists: true, route: 'agency-registration-1' },
        { name: 'Registration Step 2', path: '/components/agency/AgencyRegistrationStep2.tsx', component: 'AgencyRegistrationStep2', exists: true, route: 'agency-registration-2' },
        { name: 'Registration Step 3', path: '/components/agency/AgencyRegistrationStep3.tsx', component: 'AgencyRegistrationStep3', exists: true, route: 'agency-registration-3' },
        { name: 'Registration Step 4', path: '/components/agency/AgencyRegistrationStep4.tsx', component: 'AgencyRegistrationStep4', exists: true, route: 'agency-registration-4' },
        { name: 'Registration Step 5', path: '/components/agency/AgencyRegistrationStep5.tsx', component: 'AgencyRegistrationStep5', exists: true, route: 'agency-registration-5' },
        { name: 'Pending Verification', path: '/components/agency/PendingVerification.tsx', component: 'AgencyPendingVerification', exists: true, route: 'agency-pending-verification' },
        { name: 'Rejection View', path: '/components/agency/RejectionView.tsx', component: 'AgencyRejectionView', exists: true, route: 'agency-rejection' },
        { name: 'Onboarding', path: '/components/agency/Onboarding.tsx', component: 'AgencyOnboarding', exists: true, route: 'agency-onboarding' },
        { name: 'Dashboard', path: '/components/agency/AgencyAdminDashboard.tsx', component: 'AgencyAdminDashboard', exists: true, route: 'agency-dashboard' },
        { name: 'Subscription Plans', path: '/components/agency/SubscriptionPlans.tsx', component: 'AgencySubscriptionPlans', exists: true, route: 'agency-subscription-plans' },
        { name: 'Subscription Active', path: '/components/agency/SubscriptionActive.tsx', component: 'AgencySubscriptionActive', exists: true, route: 'agency-subscription-active' },
        { name: 'Caregiver Roster', path: '/components/agency/CaregiverRoster.tsx', component: 'CaregiverRoster', exists: true, route: 'agency-caregivers' },
        { name: 'Add Caregiver Options', path: '/components/agency/AddCaregiverOptions.tsx', component: 'AddCaregiverOptions', exists: true, route: 'agency-add-caregiver' },
        { name: 'Caregiver Pool Search', path: '/components/agency/CaregiverPoolSearch.tsx', component: 'CaregiverPoolSearch', exists: true, route: 'agency-caregiver-pool' },
        { name: 'Caregiver Profile View', path: '/components/agency/CaregiverProfileView.tsx', component: 'AgencyCaregiverProfileView', exists: true, route: 'agency-caregiver-profile' },
        { name: 'Package Management', path: '/components/agency/PackageManagement.tsx', component: 'PackageManagement', exists: true, route: 'agency-packages' },
        { name: 'Create/Edit Package', path: '/components/agency/CreatePackage.tsx', component: 'CreatePackage', exists: true, route: 'agency-create-package' },
        { name: 'Package Inquiries', path: '/components/agency/PackageInquiries.tsx', component: 'PackageInquiries', exists: true, route: 'agency-inquiries' },
        { name: 'Review Counter-Offer', path: '/components/agency/ReviewCounterOffer.tsx', component: 'ReviewCounterOffer', exists: true, route: 'agency-review-offer' },
        { name: 'Job Inbox', path: '/components/agency/JobInbox.tsx', component: 'JobInbox', exists: true, route: 'agency-jobs' },
        { name: 'New Job - Needs Assignment', path: '/components/agency/NewJobNeedsAssignment.tsx', component: 'NewJobNeedsAssignment', exists: true, route: 'agency-job-detail' },
        { name: 'Assign Caregiver Flow', path: '/components/agency/AssignCaregiverFlow.tsx', component: 'AssignCaregiverFlow', exists: true, route: 'agency-assign-caregiver' },
        { name: 'Messages Inbox', path: '/components/agency/MessagesInbox.tsx', component: 'AgencyMessagesInbox', exists: true, route: 'agency-messages' },
        { name: 'Billing & Finance', path: '/components/agency/BillingFinance.tsx', component: 'AgencyBillingFinance', exists: true, route: 'agency-billing' },
      ]
    },
    {
      role: 'Agency Manager',
      icon: Briefcase,
      total: 10,
      created: 10,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Login', path: '/components/agency/ManagerLogin.tsx', component: 'AgencyManagerLogin', exists: true, route: 'agency-manager-login' },
        { name: 'Dashboard', path: '/components/agency/ManagerDashboard.tsx', component: 'AgencyManagerDashboard', exists: true, route: 'agency-manager-dashboard' },
        { name: 'QA Dashboard', path: '/components/agency/QADashboard.tsx', component: 'QADashboard', exists: true, route: 'agency-manager-qa' },
        { name: 'Quality Dashboard ➕', path: '/components/agency/QualityDashboard.tsx', component: 'QualityDashboard', exists: true, route: 'agency-manager-quality' },
        { name: 'Quality Alerts', path: '/components/agency/QualityAlerts.tsx', component: 'QualityAlerts', exists: true, route: 'agency-manager-alerts' },
        { name: 'Alerts ➕', path: '/components/agency/Alerts.tsx', component: 'Alerts', exists: true, route: 'agency-manager-all-alerts' },
        { name: 'Feedback Queue', path: '/components/agency/FeedbackQueue.tsx', component: 'FeedbackQueue', exists: true, route: 'agency-manager-feedback' },
        { name: 'Respond to Feedback', path: '/components/agency/RespondToFeedback.tsx', component: 'RespondToFeedback', exists: true, route: 'agency-manager-respond' },
        { name: 'Reports', path: '/components/agency/Reports.tsx', component: 'AgencyReports', exists: true, route: 'agency-manager-reports' },
        { name: 'View Assignments (Read-Only)', path: '/components/agency/ViewAssignments.tsx', component: 'ViewAssignments', exists: true, route: 'agency-manager-assignments' },
      ]
    },
    {
      role: 'Caregiver',
      icon: Heart,
      total: 34,
      created: 34,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Registration Step 1', path: '/components/caregiver/CaregiverRegistration.tsx', component: 'CaregiverRegistration', exists: true, route: 'caregiver-registration-1' },
        { name: 'Registration Step 2', path: '/components/caregiver/CaregiverRegistrationStep2.tsx', component: 'CaregiverRegistrationStep2', exists: true, route: 'caregiver-registration-2' },
        { name: 'Registration Step 3', path: '/components/caregiver/CaregiverRegistrationStep3.tsx', component: 'CaregiverRegistrationStep3', exists: true, route: 'caregiver-registration-3' },
        { name: 'Registration Step 4', path: '/components/caregiver/CaregiverRegistrationStep4.tsx', component: 'CaregiverRegistrationStep4', exists: true, route: 'caregiver-registration-4' },
        { name: 'Registration Step 5', path: '/components/caregiver/CaregiverRegistrationStep5.tsx', component: 'CaregiverRegistrationStep5', exists: true, route: 'caregiver-registration-5' },
        { name: 'Registration Step 6', path: '/components/caregiver/CaregiverRegistrationStep6.tsx', component: 'CaregiverRegistrationStep6', exists: true, route: 'caregiver-registration-6' },
        { name: 'Pending Verification', path: '/components/caregiver/PendingVerification.tsx', component: 'CaregiverPendingVerification', exists: true, route: 'caregiver-pending-verification' },
        { name: 'Verification - Certificates', path: '/components/caregiver/VerificationCertificates.tsx', component: 'VerificationCertificates', exists: true, route: 'caregiver-verification-certificates' },
        { name: 'Verification - Police Clearance', path: '/components/caregiver/VerificationPoliceClearance.tsx', component: 'VerificationPoliceClearance', exists: true, route: 'caregiver-verification-police' },
        { name: 'Verification - Police ➕', path: '/components/caregiver/VerificationPolice.tsx', component: 'VerificationPolice', exists: true, route: 'caregiver-verification-police-alt' },
        { name: 'Verification - Interview', path: '/components/caregiver/VerificationInterview.tsx', component: 'VerificationInterview', exists: true, route: 'caregiver-verification-interview' },
        { name: 'Verification - Psychological Test', path: '/components/caregiver/VerificationPsychTest.tsx', component: 'VerificationPsychTest', exists: true, route: 'caregiver-verification-psych' },
        { name: 'Verification - Psych ➕', path: '/components/caregiver/VerificationPsych.tsx', component: 'VerificationPsych', exists: true, route: 'caregiver-verification-psych-alt' },
        { name: 'Verification - Physical ➕', path: '/components/caregiver/VerificationPhysical.tsx', component: 'VerificationPhysical', exists: true, route: 'caregiver-verification-physical' },
        { name: 'Verification - Document Check', path: '/components/caregiver/VerificationDocumentCheck.tsx', component: 'VerificationDocumentCheck', exists: true, route: 'caregiver-verification-document' },
        { name: 'Verification Complete', path: '/components/caregiver/VerificationComplete.tsx', component: 'VerificationComplete', exists: true, route: 'caregiver-verification-complete' },
        { name: 'Verification Failed', path: '/components/caregiver/VerificationFailed.tsx', component: 'VerificationFailed', exists: true, route: 'caregiver-verification-failed' },
        { name: 'Dashboard', path: '/components/caregiver/CaregiverDashboard.tsx', component: 'CaregiverDashboard', exists: true, route: 'caregiver-home' },
        { name: 'Subscription Plans', path: '/components/caregiver/SubscriptionPlans.tsx', component: 'CaregiverSubscriptionPlans', exists: true, route: 'caregiver-subscription' },
        { name: 'Availability Management ➕', path: '/components/caregiver/AvailabilityManagement.tsx', component: 'AvailabilityManagement', exists: true, route: 'caregiver-availability' },
        { name: 'My Jobs List', path: '/components/caregiver/MyJobs.tsx', component: 'MyJobs', exists: true, route: 'caregiver-jobs' },
        { name: 'Job Detail', path: '/components/caregiver/CaregiverJobDetail.tsx', component: 'CaregiverJobDetail', exists: true, route: 'caregiver-job-detail' },
        { name: 'Job Offer Notification', path: '/components/caregiver/JobOfferNotification.tsx', component: 'JobOfferNotification', exists: true, route: 'caregiver-job-offer' },
        { name: 'Check-In Flow', path: '/components/caregiver/CheckIn.tsx', component: 'CheckIn', exists: true, route: 'caregiver-check-in' },
        { name: 'Check-In (Alternative) ➕', path: '/components/caregiver/CheckInAlt.tsx', component: 'CheckInAlt', exists: true, route: 'caregiver-checkin-alt' },
        { name: 'Check-Out Flow', path: '/components/caregiver/CheckOutFlow.tsx', component: 'CheckOutFlow', exists: true, route: 'caregiver-check-out' },
        { name: 'Check-Out (Alternative) ➕', path: '/components/caregiver/CheckOutAlt.tsx', component: 'CheckOutAlt', exists: true, route: 'caregiver-checkout-alt' },
        { name: 'Care Log Interface', path: '/components/caregiver/CareLogInterface.tsx', component: 'CareLogInterface', exists: true, route: 'caregiver-care-logs' },
        { name: 'Care Log - Vitals', path: '/components/caregiver/CareLogVitals.tsx', component: 'CareLogVitals', exists: true, route: 'caregiver-log-vitals' },
        { name: 'Care Log - Medication', path: '/components/caregiver/CareLogMedication.tsx', component: 'CareLogMedication', exists: true, route: 'caregiver-log-medication' },
        { name: 'Care Log - Medications List ➕', path: '/components/caregiver/CareLogMedicationsList.tsx', component: 'CareLogMedicationsList', exists: true, route: 'caregiver-log-medications' },
        { name: 'Care Log - Activity', path: '/components/caregiver/CareLogActivity.tsx', component: 'CareLogActivity', exists: true, route: 'caregiver-log-activity' },
        { name: 'Care Log - Activities List ➕', path: '/components/caregiver/CareLogActivitiesList.tsx', component: 'CareLogActivitiesList', exists: true, route: 'caregiver-log-activities' },
        { name: 'Care Log - Incident', path: '/components/caregiver/CareLogIncident.tsx', component: 'CareLogIncident', exists: true, route: 'caregiver-log-incident' },
        { name: 'Earnings Summary', path: '/components/caregiver/Earnings.tsx', component: 'Earnings', exists: true, route: 'caregiver-earnings' },
        { name: 'Earnings Withdraw ➕', path: '/components/caregiver/EarningsWithdraw.tsx', component: 'EarningsWithdraw', exists: true, route: 'caregiver-earnings-withdraw' },
        { name: 'Generate Invoice', path: '/components/caregiver/GenerateInvoice.tsx', component: 'GenerateInvoice', exists: true, route: 'caregiver-invoice' },
        { name: 'History ➕', path: '/components/caregiver/History.tsx', component: 'History', exists: true, route: 'caregiver-history' },
        { name: 'Emergency ➕', path: '/components/caregiver/Emergency.tsx', component: 'Emergency', exists: true, route: 'caregiver-emergency' },
        { name: 'Training ➕', path: '/components/caregiver/Training.tsx', component: 'Training', exists: true, route: 'caregiver-training' },
        { name: 'Messages Inbox', path: '/components/caregiver/MessagesInbox.tsx', component: 'CaregiverMessagesInbox', exists: true, route: 'caregiver-messages' },
        { name: 'Account Locked State', path: '/components/caregiver/AccountLocked.tsx', component: 'CaregiverAccountLocked', exists: true, route: 'caregiver-account-locked' },
      ]
    },
    {
      role: 'Patient',
      icon: Users,
      total: 15,
      created: 15,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Login', path: '/components/patient/PatientLogin.tsx', component: 'PatientLogin', exists: true, route: 'patient-login' },
        { name: 'Dashboard', path: '/components/patient/PatientDashboard.tsx', component: 'PatientDashboard', exists: true, route: 'patient-home' },
        { name: 'My Caregiver', path: '/components/patient/MyCaregiverProfile.tsx', component: 'MyCaregiverProfile', exists: true, route: 'patient-caregiver' },
        { name: 'Medication Schedule', path: '/components/patient/MedicationSchedule.tsx', component: 'MedicationSchedule', exists: true, route: 'patient-medications' },
        { name: 'Medication Reminder', path: '/components/patient/MedicationReminder.tsx', component: 'MedicationReminder', exists: true, route: 'patient-medication-reminder' },
        { name: 'Care Logs View', path: '/components/patient/CareLogsView.tsx', component: 'CareLogsView', exists: true, route: 'patient-care-logs' },
        { name: 'Appointments/Schedule', path: '/components/patient/AppointmentsSchedule.tsx', component: 'AppointmentsSchedule', exists: true, route: 'patient-appointments' },
        { name: 'Schedule ➕', path: '/components/patient/PatientSchedule.tsx', component: 'PatientSchedule', exists: true, route: 'patient-schedule' },
        { name: 'Emergency Contacts', path: '/components/patient/EmergencyContacts.tsx', component: 'EmergencyContacts', exists: true, route: 'patient-emergency-contacts' },
        { name: 'Emergency SOS', path: '/components/patient/EmergencySOS.tsx', component: 'EmergencySOS', exists: true, route: 'patient-emergency-sos' },
        { name: 'Rate Caregiver', path: '/components/patient/RateCaregiver.tsx', component: 'RateCaregiver', exists: true, route: 'patient-rate-caregiver' },
        { name: 'Chat with Caregiver', path: '/components/patient/ChatWithCaregiver.tsx', component: 'ChatWithCaregiver', exists: true, route: 'patient-chat' },
        { name: 'Profile View (Read-Only)', path: '/components/patient/ProfileView.tsx', component: 'PatientProfileView', exists: true, route: 'patient-profile' },
        { name: 'Health Records ➕', path: '/components/patient/PatientHealthRecords.tsx', component: 'PatientHealthRecords', exists: true, route: 'patient-health-records' },
        { name: 'Settings ➕', path: '/components/patient/PatientSettings.tsx', component: 'PatientSettings', exists: true, route: 'patient-settings' },
      ]
    },
    {
      role: 'Platform Moderator',
      icon: Shield,
      total: 25,
      created: 25,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Login with MFA', path: '/components/moderator/ModeratorLogin.tsx', component: 'ModeratorLogin', exists: true, route: 'moderator-login' },
        { name: 'Dashboard', path: '/components/moderator/ModeratorDashboard.tsx', component: 'ModeratorDashboard', exists: true, route: 'moderator-dashboard' },
        { name: 'Agency Package Template', path: '/components/moderator/AgencyPackageTemplate.tsx', component: 'AgencyPackageTemplate', exists: true, route: 'moderator-agency-package-template' },
        { name: 'Caregiver Package Template', path: '/components/moderator/CaregiverPackageTemplate.tsx', component: 'CaregiverPackageTemplate', exists: true, route: 'moderator-caregiver-package-template' },
        { name: 'Agency Subscription Creator', path: '/components/moderator/AgencySubscriptionCreator.tsx', component: 'AgencySubscriptionCreator', exists: true, route: 'moderator-agency-subscription' },
        { name: 'Caregiver Subscription Creator', path: '/components/moderator/CaregiverSubscriptionCreator.tsx', component: 'CaregiverSubscriptionCreator', exists: true, route: 'moderator-caregiver-subscription' },
        { name: 'Verification Queue - Agencies', path: '/components/moderator/VerificationQueueAgencies.tsx', component: 'VerificationQueueAgencies', exists: true, route: 'moderator-verification-agencies' },
        { name: 'Verification Queue - Caregivers', path: '/components/moderator/VerificationQueueCaregivers.tsx', component: 'VerificationQueueCaregivers', exists: true, route: 'moderator-verification-caregivers' },
        { name: 'Agency Verification Review', path: '/components/moderator/AgencyVerificationReview.tsx', component: 'AgencyVerificationReview', exists: true, route: 'moderator-agency-verification-review' },
        { name: 'Agency Legal Document Queue', path: '/components/moderator/AgencyLegalDocQueue.tsx', component: 'AgencyLegalDocQueue', exists: true, route: 'moderator-legal-queue' },
        { name: 'Agency Physical Verification Queue', path: '/components/moderator/AgencyPhysicalQueue.tsx', component: 'AgencyPhysicalQueue', exists: true, route: 'moderator-physical-queue' },
        { name: 'Caregiver Certificate Queue', path: '/components/moderator/CaregiverCertificateQueue.tsx', component: 'CaregiverCertificateQueue', exists: true, route: 'moderator-certificate-queue' },
        { name: 'Caregiver Police Clearance Queue', path: '/components/moderator/CaregiverPoliceQueue.tsx', component: 'CaregiverPoliceQueue', exists: true, route: 'moderator-police-queue' },
        { name: 'Caregiver Interview Queue', path: '/components/moderator/CaregiverInterviewQueue.tsx', component: 'CaregiverInterviewQueue', exists: true, route: 'moderator-interview-queue' },
        { name: 'Caregiver Psychological Analysis Queue', path: '/components/moderator/CaregiverPsychQueue.tsx', component: 'CaregiverPsychQueue', exists: true, route: 'moderator-psych-queue' },
        { name: 'Caregiver Pipeline View', path: '/components/moderator/CaregiverPipelineView.tsx', component: 'CaregiverPipelineView', exists: true, route: 'moderator-pipeline-view' },
        { name: 'CV Pool Management', path: '/components/moderator/CVPoolManagement.tsx', component: 'CVPoolManagement', exists: true, route: 'moderator-cv-pool' },
        { name: 'Dispute Center', path: '/components/moderator/DisputeCenter.tsx', component: 'DisputeCenter', exists: true, route: 'moderator-disputes' },
        { name: 'Dispute Detail', path: '/components/moderator/DisputeDetail.tsx', component: 'DisputeDetail', exists: true, route: 'moderator-dispute-detail' },
        { name: 'Support Tickets Queue', path: '/components/moderator/SupportTicketsQueue.tsx', component: 'SupportTicketsQueue', exists: true, route: 'moderator-tickets' },
        { name: 'Ticket Response', path: '/components/moderator/TicketResponse.tsx', component: 'TicketResponse', exists: true, route: 'moderator-ticket-response' },
        { name: 'Platform Analytics', path: '/components/moderator/PlatformAnalytics.tsx', component: 'ModeratorPlatformAnalytics', exists: true, route: 'moderator-analytics' },
        { name: 'Billing / Invoices', path: '/components/moderator/BillingInvoices.tsx', component: 'ModeratorBillingInvoices', exists: true, route: 'moderator-billing' },
        { name: 'Messages / Communication', path: '/components/moderator/MessagesCommunication.tsx', component: 'ModeratorMessagesCommunication', exists: true, route: 'moderator-messages' },
        { name: 'Settings', path: '/components/moderator/Settings.tsx', component: 'ModeratorSettings', exists: true, route: 'moderator-settings' },
      ]
    },
    {
      role: 'Platform Admin',
      icon: UserCog,
      total: 31,
      created: 5,
      percentage: 16,
      status: 'low',
      pages: [
        { name: 'Login with MFA', path: '/components/admin/AdminLogin.tsx', component: 'AdminLogin', exists: true, route: 'admin-login' },
        { name: 'MFA Failed', path: '/components/admin/AdminMFAFailed.tsx', component: 'AdminMFAFailed', exists: true, route: 'admin-mfa-failed' },
        { name: 'Dashboard', path: '/components/admin/AdminDashboard.tsx', component: 'AdminDashboard', exists: true, route: 'admin-dashboard' },
        { name: 'Agency Package Template Editor', path: '/components/admin/AdminAgencyPackageTemplate.tsx', component: 'AdminAgencyPackageTemplate', exists: false, route: 'admin-agency-template' },
        { name: 'Caregiver Package Template Editor', path: '/components/admin/AdminCaregiverPackageTemplate.tsx', component: 'AdminCaregiverPackageTemplate', exists: false, route: 'admin-caregiver-template' },
        { name: 'Agency Subscription Creator', path: '/components/admin/AdminAgencySubscription.tsx', component: 'AdminAgencySubscription', exists: false, route: 'admin-agency-subscription' },
        { name: 'Caregiver Subscription Creator', path: '/components/admin/AdminCaregiverSubscription.tsx', component: 'AdminCaregiverSubscription', exists: false, route: 'admin-caregiver-subscription' },
        { name: 'Moderator Management', path: '/components/admin/ModeratorManagement.tsx', component: 'ModeratorManagement', exists: true, route: 'admin-moderators' },
        { name: 'Add Moderator', path: '/components/admin/AddModerator.tsx', component: 'AddModerator', exists: false, route: 'admin-add-moderator' },
        { name: 'Edit Moderator', path: '/components/admin/EditModerator.tsx', component: 'EditModerator', exists: false, route: 'admin-edit-moderator' },
        { name: 'Moderator Submissions Queue', path: '/components/admin/ModeratorSubmissions.tsx', component: 'ModeratorSubmissions', exists: false, route: 'admin-submissions' },
        { name: 'Submission Review Panel', path: '/components/admin/SubmissionReview.tsx', component: 'SubmissionReview', exists: false, route: 'admin-submission-review' },
        { name: 'Admin Decision (3-Way)', path: '/components/admin/AdminDecision.tsx', component: 'AdminDecision', exists: false, route: 'admin-decision' },
        { name: 'Agency Legal Doc Review', path: '/components/admin/AdminLegalDocReview.tsx', component: 'AdminLegalDocReview', exists: false, route: 'admin-legal-review' },
        { name: 'Agency Physical Verification Review', path: '/components/admin/AdminPhysicalReview.tsx', component: 'AdminPhysicalReview', exists: false, route: 'admin-physical-review' },
        { name: 'Caregiver Certificate Review', path: '/components/admin/AdminCertificateReview.tsx', component: 'AdminCertificateReview', exists: false, route: 'admin-certificate-review' },
        { name: 'Caregiver Police Clearance Review', path: '/components/admin/AdminPoliceReview.tsx', component: 'AdminPoliceReview', exists: false, route: 'admin-police-review' },
        { name: 'Caregiver Interview Review', path: '/components/admin/AdminInterviewReview.tsx', component: 'AdminInterviewReview', exists: false, route: 'admin-interview-review' },
        { name: 'Caregiver Psych Analysis Review', path: '/components/admin/AdminPsychReview.tsx', component: 'AdminPsychReview', exists: false, route: 'admin-psych-review' },
        { name: 'Caregiver Direct Verification Queue', path: '/components/admin/AdminCaregiverVerification.tsx', component: 'AdminCaregiverVerification', exists: false, route: 'admin-caregiver-verification' },
        { name: 'Agency Verification Queue', path: '/components/admin/AdminAgencyVerification.tsx', component: 'AdminAgencyVerification', exists: false, route: 'admin-agency-verification' },
        { name: 'Dispute Center (Escalated)', path: '/components/admin/AdminDisputes.tsx', component: 'AdminDisputes', exists: false, route: 'admin-disputes' },
        { name: 'CV Pool Management', path: '/components/admin/AdminCVPool.tsx', component: 'AdminCVPool', exists: false, route: 'admin-cv-pool' },
        { name: 'Support Tickets (Escalated)', path: '/components/admin/AdminTickets.tsx', component: 'AdminTickets', exists: false, route: 'admin-tickets' },
        { name: 'Platform Analytics', path: '/components/admin/AdminAnalytics.tsx', component: 'AdminAnalytics', exists: false, route: 'admin-analytics' },
        { name: 'Audit Logs', path: '/components/admin/AdminAuditLogs.tsx', component: 'AdminAuditLogs', exists: true, route: 'admin-audit-logs' },
        { name: 'System Settings', path: '/components/admin/AdminSystemSettings.tsx', component: 'AdminSystemSettings', exists: false, route: 'admin-settings' },
        { name: 'Locked Accounts', path: '/components/admin/AdminLockedAccounts.tsx', component: 'AdminLockedAccounts', exists: false, route: 'admin-locked-accounts' },
        { name: 'Manual Unlock', path: '/components/admin/AdminManualUnlock.tsx', component: 'AdminManualUnlock', exists: false, route: 'admin-manual-unlock' },
        { name: 'Messages / Communication', path: '/components/admin/AdminMessages.tsx', component: 'AdminMessages', exists: false, route: 'admin-messages' },
        { name: 'Billing Management', path: '/components/admin/AdminBilling.tsx', component: 'AdminBilling', exists: false, route: 'admin-billing' },
      ]
    },
    {
      role: 'Shop Admin',
      icon: Store,
      total: 15,
      created: 15,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Registration', path: '/components/shop/ShopRegistration.tsx', component: 'ShopRegistration', exists: true, route: 'shop-registration' },
        { name: 'Pending Verification', path: '/components/shop/ShopPendingVerification.tsx', component: 'ShopPendingVerification', exists: true, route: 'shop-pending-verification' },
        { name: 'Dashboard', path: '/components/shop/ShopDashboard.tsx', component: 'ShopDashboard', exists: true, route: 'shop-dashboard' },
        { name: 'Product Management', path: '/components/shop/ProductManagement.tsx', component: 'ProductManagement', exists: true, route: 'shop-products' },
        { name: 'Add/Edit Product', path: '/components/shop/AddEditProduct.tsx', component: 'AddEditProduct', exists: true, route: 'shop-add-product' },
        { name: 'Order Management', path: '/components/shop/OrderManagement.tsx', component: 'OrderManagement', exists: true, route: 'shop-orders' },
        { name: 'Order Detail', path: '/components/shop/OrderDetail.tsx', component: 'OrderDetail', exists: true, route: 'shop-order-detail' },
        { name: 'Update Order Status', path: '/components/shop/UpdateOrderStatus.tsx', component: 'UpdateOrderStatus', exists: true, route: 'shop-update-status' },
        { name: 'Messages Inbox', path: '/components/shop/ShopMessagesInbox.tsx', component: 'ShopMessagesInbox', exists: true, route: 'shop-messages' },
        { name: 'Shop Analytics', path: '/components/shop/ShopAnalytics.tsx', component: 'ShopAnalytics', exists: true, route: 'shop-analytics' },
        { name: 'Billing', path: '/components/shop/ShopBilling.tsx', component: 'ShopBilling', exists: true, route: 'shop-billing' },
        { name: 'Payment Reminder (Day 3)', path: '/components/shop/ShopPaymentReminder.tsx', component: 'ShopPaymentReminder', exists: true, route: 'shop-payment-reminder' },
        { name: 'Payment Warning (Day 5)', path: '/components/shop/ShopPaymentWarning.tsx', component: 'ShopPaymentWarning', exists: true, route: 'shop-payment-warning' },
        { name: 'Payment Final Warning (Day 6)', path: '/components/shop/ShopPaymentFinalWarning.tsx', component: 'ShopPaymentFinalWarning', exists: true, route: 'shop-payment-final-warning' },
        { name: 'Account Locked (Day 7+)', path: '/components/shop/ShopAccountLocked.tsx', component: 'ShopAccountLocked', exists: true, route: 'shop-account-locked' },
      ]
    },
    {
      role: 'Shop Manager',
      icon: Store,
      total: 10,
      created: 10,
      percentage: 100,
      status: 'complete',
      pages: [
        { name: 'Login', path: '/components/shop/ShopManagerLogin.tsx', component: 'ShopManagerLogin', exists: true, route: 'shop-manager-login' },
        { name: 'Dashboard', path: '/components/shop/ShopManagerDashboard.tsx', component: 'ShopManagerDashboard', exists: true, route: 'shop-manager-dashboard' },
        { name: 'Order Queue', path: '/components/shop/ShopManagerOrderQueue.tsx', component: 'ShopManagerOrderQueue', exists: true, route: 'shop-manager-orders' },
        { name: 'Order Detail', path: '/components/shop/ShopManagerOrderDetail.tsx', component: 'ShopManagerOrderDetail', exists: true, route: 'shop-manager-order-detail' },
        { name: 'Inventory Management', path: '/components/shop/ShopManagerInventory.tsx', component: 'ShopManagerInventory', exists: true, route: 'shop-manager-inventory' },
        { name: 'Update Stock', path: '/components/shop/ShopManagerUpdateStock.tsx', component: 'ShopManagerUpdateStock', exists: true, route: 'shop-manager-update-stock' },
        { name: 'Low Stock Alerts', path: '/components/shop/ShopManagerLowStockAlerts.tsx', component: 'ShopManagerLowStockAlerts', exists: true, route: 'shop-manager-alerts' },
        { name: 'Customer Inquiries', path: '/components/shop/ShopManagerInquiries.tsx', component: 'ShopManagerInquiries', exists: true, route: 'shop-manager-inquiries' },
        { name: 'Chat with Shop Admin', path: '/components/shop/ShopManagerChat.tsx', component: 'ShopManagerChat', exists: true, route: 'shop-manager-chat' },
        { name: 'View Restrictions Summary', path: '/components/shop/ShopManagerRestrictions.tsx', component: 'ShopManagerRestrictions', exists: true, route: 'shop-manager-restrictions' },
      ]
    }
  ];

  const totalPages = sections.reduce((sum, section) => sum + section.total, 0);
  const totalCreated = sections.reduce((sum, section) => sum + section.created, 0);
  const overallPercentage = Math.round((totalCreated / totalPages) * 100);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'complete': return 'bg-green-500';
      case 'high': return 'bg-blue-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-orange-500';
      default: return 'bg-gray-400';
    }
  };

  const handlePageClick = (page: Page) => {
    setSelectedPage(page.route);
    if (page.exists && onNavigate) {
      onNavigate(page.route);
    }
  };

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#F5F7FA' }}>
      {/* Header */}
      <div className="sticky top-0 z-10 p-6 finance-card">
        <h1 className="mb-2" style={{ color: '#535353' }}>CareNet Platform</h1>
        <p style={{ color: '#848484' }}>Page Inventory & Navigation</p>
        
        {/* Overall Progress */}
        <div className="mt-4 p-4 rounded-xl" style={{ background: 'rgba(102, 126, 234, 0.1)' }}>
          <div className="flex items-center justify-between mb-2">
            <span style={{ color: '#535353' }}>Overall Progress</span>
            <span style={{ color: '#667eea' }}>{totalCreated} / {totalPages}</span>
          </div>
          <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'rgba(132, 132, 132, 0.1)' }}>
            <div 
              className="h-2 rounded-full transition-all duration-300"
              style={{ 
                width: `${overallPercentage}%`,
                background: 'linear-gradient(90deg, #667eea 0%, #764ba2 100%)'
              }}
            />
          </div>
          <p className="text-sm mt-1 text-center" style={{ color: '#848484' }}>{overallPercentage}% Complete</p>
        </div>
      </div>

      {/* Sections */}
      <div className="p-6 space-y-4">
        {sections.map((section) => (
          <div key={section.role} className="finance-card overflow-hidden">
            <button
              onClick={() => toggleSection(section.role)}
              className="w-full p-4 flex items-center justify-between hover:bg-opacity-80 transition-all"
            >
              <div className="flex items-center gap-3">
                <div 
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${getStatusColor(section.status)}`}
                >
                  <section.icon className="w-5 h-5 text-white" />
                </div>
                <div className="text-left">
                  <p style={{ color: '#535353' }}>{section.role}</p>
                  <p className="text-sm" style={{ color: '#848484' }}>
                    {section.created} / {section.total} pages
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 rounded-full text-xs text-white ${getStatusColor(section.status)}`}>
                  {section.percentage}%
                </span>
                {expandedSections.includes(section.role) ? 
                  <ChevronDown className="w-5 h-5" style={{ color: '#848484' }} /> : 
                  <ChevronRight className="w-5 h-5" style={{ color: '#848484' }} />
                }
              </div>
            </button>

            {expandedSections.includes(section.role) && (
              <div className="px-4 pb-4 space-y-2">
                {section.pages.map((page, index) => (
                  <button
                    key={index}
                    onClick={() => handlePageClick(page)}
                    className={`w-full p-3 rounded-lg flex items-center justify-between transition-all ${
                      selectedPage === page.route ? 'ring-2 ring-blue-500' : ''
                    }`}
                    style={{
                      backgroundColor: page.exists ? 'rgba(168, 224, 99, 0.1)' : 'rgba(255, 179, 193, 0.1)'
                    }}
                  >
                    <div className="flex items-center gap-3">
                      {page.exists ? 
                        <CheckCircle2 className="w-5 h-5" style={{ color: '#7CE577' }} /> :
                        <Circle className="w-5 h-5" style={{ color: '#FFB3C1' }} />
                      }
                      <div className="text-left">
                        <p className="text-sm" style={{ color: '#535353' }}>{page.name}</p>
                        <p className="text-xs" style={{ color: '#848484' }}>{page.route}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}