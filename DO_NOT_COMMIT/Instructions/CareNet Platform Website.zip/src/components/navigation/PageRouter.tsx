import React from 'react';

// This is a comprehensive router that maps all 190+ page routes to their components
// Components that don't exist yet will show a placeholder

// Import all existing components
import { LandingPage } from '../shared/LandingPage';
import { Login } from '../auth/Login';
import { RoleSelection } from '../auth/RoleSelection';
import { MFAVerification } from '../shared/MFAVerification';
import { PasswordReset } from '../shared/PasswordReset';
import { NotFound } from '../shared/NotFound';
import { OfflineState } from '../shared/OfflineState';
import { TermsAndConditions } from '../shared/TermsAndConditions';
import { PrivacyPolicy } from '../shared/PrivacyPolicy';

import { GuardianDashboard } from '../guardian/GuardianDashboard';
import { CaregiverDashboard } from '../caregiver/CaregiverDashboard';
import { AdminDashboard } from '../admin/AdminDashboard';
import { AdminLogin } from '../admin/AdminLogin';
import { AdminMFAFailed } from '../admin/AdminMFAFailed';
import { ModeratorManagement } from '../admin/ModeratorManagement';
import { AdminAuditLogs } from '../admin/AdminAuditLogs';

// Moderator imports
import { CaregiverInterviewQueue } from '../moderator/CaregiverInterviewQueue';

// Caregiver imports
import { CaregiverRegistration } from '../caregiver/CaregiverRegistration';
import { CaregiverRegistrationStep2 } from '../caregiver/CaregiverRegistrationStep2';
import { CaregiverRegistrationStep3 } from '../caregiver/CaregiverRegistrationStep3';
import { CaregiverRegistrationStep4 } from '../caregiver/CaregiverRegistrationStep4';
import { CaregiverRegistrationStep5 } from '../caregiver/CaregiverRegistrationStep5';
import { CaregiverRegistrationStep6 } from '../caregiver/CaregiverRegistrationStep6';
import { PendingVerification } from '../caregiver/PendingVerification';
import { VerificationCertificates } from '../caregiver/VerificationCertificates';
import { VerificationPoliceClearance } from '../caregiver/VerificationPoliceClearance';
import { VerificationInterview } from '../caregiver/VerificationInterview';
import { VerificationPsychTest } from '../caregiver/VerificationPsychTest';
import { VerificationPhysical } from '../caregiver/VerificationPhysical';
import { VerificationDocumentCheck } from '../caregiver/VerificationDocumentCheck';
import { VerificationComplete } from '../caregiver/VerificationComplete';
import { VerificationFailed } from '../caregiver/VerificationFailed';
import { SubscriptionPlans } from '../caregiver/SubscriptionPlans';
import { MyJobs } from '../caregiver/MyJobs';
import { CaregiverJobDetail } from '../caregiver/CaregiverJobDetail';
import { JobOfferNotification } from '../caregiver/JobOfferNotification';
import { CheckIn } from '../caregiver/CheckIn';
import { CheckOutFlow } from '../caregiver/CheckOutFlow';
import { CareLogInterface } from '../caregiver/CareLogInterface';
import { CareLogVitals } from '../caregiver/CareLogVitals';
import { CareLogMedication } from '../caregiver/CareLogMedication';
import { CareLogActivity } from '../caregiver/CareLogActivity';
import { CareLogIncident } from '../caregiver/CareLogIncident';
import { Earnings } from '../caregiver/Earnings';
import { GenerateInvoice } from '../caregiver/GenerateInvoice';

interface PageRouterProps {
  currentPage: string;
  onNavigate?: (page: string) => void;
  userRole?: string;
  userName?: string;
}

// Placeholder component for pages that don't exist yet
function PlaceholderPage({ pageName, onNavigate }: { pageName: string; onNavigate?: (page: string) => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="finance-card p-8 text-center max-w-md">
        <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
          style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FFB3C1 0%, #FF8FA3 100%)' }}>
          <span className="text-2xl">🚧</span>
        </div>
        <h2 className="mb-2" style={{ color: '#535353' }}>Page Under Construction</h2>
        <p className="mb-4" style={{ color: '#848484' }}>{pageName}</p>
        <p className="text-sm mb-6" style={{ color: '#848484' }}>
          This page is part of the CareNet platform and will be implemented soon.
        </p>
        <button
          onClick={() => onNavigate?.('toc')}
          className="px-6 py-3 rounded-xl text-white"
          style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}
        >
          Back to Table of Contents
        </button>
      </div>
    </div>
  );
}

export default function PageRouter({ currentPage, onNavigate, userRole, userName = 'User' }: PageRouterProps) {
  
  // Handle special case for TOC
  if (currentPage === 'toc') {
    // This will be handled by App.tsx showing TableOfContents
    return null;
  }

  switch (currentPage) {
    // ==================== SHARED / AUTHENTICATION PAGES ====================
    case 'landing':
      return <LandingPage onNavigateToLogin={() => onNavigate?.('login')} onNavigateToRegister={() => onNavigate?.('role-selection')} />;
    
    case 'login':
      return <Login onLogin={() => onNavigate?.('role-selection')} onNavigateToRegister={() => onNavigate?.('role-selection')} />;
    
    case 'role-selection':
      return <RoleSelection onSelectRole={() => {}} onBack={() => onNavigate?.('login')} onNavigate={onNavigate} />;
    
    case 'mfa-verification':
      return <MFAVerification onVerify={() => {}} onUseBackupCode={() => {}} onNavigate={onNavigate} />;
    
    case 'password-reset':
    case 'password-reset-step-1':
      return <PasswordReset onBack={() => onNavigate?.('login')} onComplete={() => onNavigate?.('login')} onNavigate={onNavigate} />;
    
    case 'password-reset-step-2':
    case 'password-reset-step-3':
    case 'password-reset-success':
      return <PlaceholderPage pageName={`Password Reset - ${currentPage}`} onNavigate={onNavigate} />;
    
    case 'terms-and-conditions':
      return <TermsAndConditions onBack={() => onNavigate?.('toc')} />;
    
    case 'privacy-policy':
      return <PrivacyPolicy onBack={() => onNavigate?.('toc')} />;
    
    case 'not-found':
      return <NotFound onNavigateHome={() => onNavigate?.('toc')} onNavigateBack={() => onNavigate?.('toc')} />;
    
    case 'offline-state':
      return <OfflineState onRetry={() => window.location.reload()} />;

    // ==================== GUARDIAN PAGES ====================
    case 'guardian-registration-1':
    case 'guardian-registration-2':
    case 'guardian-registration-3':
      return <PlaceholderPage pageName={`Guardian ${currentPage}`} onNavigate={onNavigate} />;
    
    case 'guardian-home':
    case 'guardian-dashboard':
      return <GuardianDashboard userName={userName} onNavigate={onNavigate || (() => {})} />;
    
    case 'guardian-add-patient':
    case 'guardian-patients':
    case 'guardian-patient-detail':
    case 'guardian-edit-patient':
    case 'guardian-health-records':
    case 'guardian-prescription-upload':
    case 'guardian-browse-packages':
    case 'guardian-package-filters':
    case 'guardian-package-detail':
    case 'guardian-negotiation':
    case 'guardian-negotiation-waiting':
    case 'guardian-negotiation-review':
    case 'guardian-jobs':
    case 'guardian-job-detail':
    case 'guardian-messages':
    case 'guardian-chat':
    case 'guardian-billing':
    case 'guardian-payment-reminder':
    case 'guardian-payment-warning':
    case 'guardian-account-locked':
      return <PlaceholderPage pageName={`Guardian - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== AGENCY ADMIN PAGES ====================
    case 'agency-registration-1':
    case 'agency-registration-2':
    case 'agency-registration-3':
    case 'agency-registration-4':
    case 'agency-registration-5':
    case 'agency-pending-verification':
    case 'agency-rejection':
    case 'agency-onboarding':
    case 'agency-dashboard':
    case 'agency-subscription-plans':
    case 'agency-subscription-active':
    case 'agency-caregivers':
    case 'agency-add-caregiver':
    case 'agency-caregiver-pool':
    case 'agency-caregiver-profile':
    case 'agency-packages':
    case 'agency-create-package':
    case 'agency-inquiries':
    case 'agency-review-offer':
    case 'agency-jobs':
    case 'agency-job-detail':
    case 'agency-assign-caregiver':
    case 'agency-messages':
    case 'agency-billing':
      return <PlaceholderPage pageName={`Agency Admin - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== AGENCY MANAGER PAGES ====================
    case 'agency-manager-login':
    case 'agency-manager-dashboard':
    case 'agency-manager-qa':
    case 'agency-manager-alerts':
    case 'agency-manager-feedback':
    case 'agency-manager-respond':
    case 'agency-manager-reports':
    case 'agency-manager-assignments':
      return <PlaceholderPage pageName={`Agency Manager - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== CAREGIVER PAGES ====================
    case 'caregiver-registration-1':
      return <CaregiverRegistration onNavigate={onNavigate} />;
    case 'caregiver-registration-2':
      return <CaregiverRegistrationStep2 onNavigate={onNavigate} />;
    case 'caregiver-registration-3':
      return <CaregiverRegistrationStep3 onNavigate={onNavigate} />;
    case 'caregiver-registration-4':
      return <CaregiverRegistrationStep4 onNavigate={onNavigate} />;
    case 'caregiver-registration-5':
      return <CaregiverRegistrationStep5 onNavigate={onNavigate} />;
    case 'caregiver-registration-6':
      return <CaregiverRegistrationStep6 onNavigate={onNavigate} />;
    case 'caregiver-pending-verification':
      return <PendingVerification onNavigate={onNavigate} />;
    case 'caregiver-verification-certificates':
      return <VerificationCertificates onNavigate={onNavigate} />;
    case 'caregiver-verification-police':
      return <VerificationPoliceClearance onNavigate={onNavigate} />;
    case 'caregiver-verification-interview':
      return <VerificationInterview onNavigate={onNavigate} />;
    case 'caregiver-verification-psych':
      return <VerificationPsychTest onNavigate={onNavigate} />;
    case 'caregiver-verification-document':
      return <VerificationDocumentCheck onNavigate={onNavigate} />;
    case 'caregiver-verification-complete':
      return <VerificationComplete onNavigate={onNavigate} />;
    case 'caregiver-verification-failed':
      return <VerificationFailed onNavigate={onNavigate} />;
    
    case 'caregiver-home':
    case 'caregiver-dashboard':
      return <CaregiverDashboard caregiverName={userName} onNavigate={onNavigate || (() => {})} />;
    
    case 'caregiver-subscription':
      return <SubscriptionPlans onNavigate={onNavigate} />;
    case 'caregiver-jobs':
      return <MyJobs onNavigate={onNavigate} />;
    case 'caregiver-job-detail':
      return <CaregiverJobDetail onNavigate={onNavigate} />;
    case 'caregiver-job-offer':
      return <JobOfferNotification onNavigate={onNavigate} />;
    case 'caregiver-check-in':
      return <CheckIn onNavigate={onNavigate} />;
    case 'caregiver-check-out':
      return <CheckOutFlow onNavigate={onNavigate} />;
    case 'caregiver-care-logs':
      return <CareLogInterface onNavigate={onNavigate} />;
    case 'caregiver-log-vitals':
      return <CareLogVitals onNavigate={onNavigate} />;
    case 'caregiver-log-medication':
      return <CareLogMedication onNavigate={onNavigate} />;
    case 'caregiver-log-activity':
      return <CareLogActivity onNavigate={onNavigate} />;
    case 'caregiver-log-incident':
      return <CareLogIncident onNavigate={onNavigate} />;
    case 'caregiver-earnings':
      return <Earnings onNavigate={onNavigate} />;
    case 'caregiver-invoice':
      return <GenerateInvoice onNavigate={onNavigate} />;
    case 'caregiver-messages':
    case 'caregiver-account-locked':
      return <PlaceholderPage pageName={`Caregiver - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== PATIENT PAGES ====================
    case 'patient-login':
    case 'patient-home':
    case 'patient-dashboard':
    case 'patient-caregiver':
    case 'patient-medications':
    case 'patient-medication-reminder':
    case 'patient-care-logs':
    case 'patient-appointments':
    case 'patient-emergency-contacts':
    case 'patient-emergency-sos':
    case 'patient-rate-caregiver':
    case 'patient-chat':
    case 'patient-profile':
      return <PlaceholderPage pageName={`Patient - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== PLATFORM MODERATOR PAGES ====================
    case 'moderator-login':
    case 'moderator-dashboard':
    case 'moderator-agency-package-template':
    case 'moderator-caregiver-package-template':
    case 'moderator-agency-subscription':
    case 'moderator-caregiver-subscription':
    case 'moderator-verification-agencies':
    case 'moderator-verification-caregivers':
    case 'moderator-agency-verification-review':
    case 'moderator-legal-queue':
    case 'moderator-physical-queue':
    case 'moderator-certificate-queue':
    case 'moderator-police-queue':
      return <PlaceholderPage pageName={`Moderator - ${currentPage}`} onNavigate={onNavigate} />;
    
    case 'moderator-interview-queue':
      return <CaregiverInterviewQueue onNavigate={onNavigate} />;
    
    case 'moderator-psych-queue':
    case 'moderator-pipeline-view':
    case 'moderator-cv-pool':
    case 'moderator-disputes':
    case 'moderator-dispute-detail':
    case 'moderator-tickets':
    case 'moderator-ticket-response':
    case 'moderator-analytics':
    case 'moderator-billing':
    case 'moderator-messages':
    case 'moderator-settings':
      return <PlaceholderPage pageName={`Moderator - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== PLATFORM ADMIN PAGES ====================
    case 'admin-login':
      return <AdminLogin onLogin={() => onNavigate?.('admin-dashboard')} onNavigate={onNavigate} />;
    
    case 'admin-mfa-failed':
      return <AdminMFAFailed 
        onRetry={() => onNavigate?.('admin-login')} 
        onBackToLogin={() => onNavigate?.('admin-login')}
        onNavigate={onNavigate}
      />;
    
    case 'admin-dashboard':
      return <AdminDashboard 
        adminName={userName}
        onModeratorManagement={() => onNavigate?.('admin-moderators')}
        onAuditLogs={() => onNavigate?.('admin-audit-logs')}
        onSystemSettings={() => onNavigate?.('admin-settings')}
        onAnalytics={() => onNavigate?.('admin-analytics')}
        onVerificationQueue={() => onNavigate?.('admin-submissions')}
        onNavigate={onNavigate}
      />;
    
    case 'admin-moderators':
      return <ModeratorManagement
        onAddModerator={() => onNavigate?.('admin-add-moderator')}
        onEditModerator={(id) => onNavigate?.('admin-edit-moderator')}
        onNavigate={onNavigate}
      />;
    
    case 'admin-audit-logs':
      return <AdminAuditLogs
        onExport={() => console.log('Export audit logs')}
        onViewDetails={(id) => console.log('View details:', id)}
        onNavigate={onNavigate}
      />;
    
    case 'admin-agency-template':
    case 'admin-caregiver-template':
    case 'admin-agency-subscription':
    case 'admin-caregiver-subscription':
    case 'admin-add-moderator':
    case 'admin-edit-moderator':
    case 'admin-submissions':
    case 'admin-submission-review':
    case 'admin-decision':
    case 'admin-legal-review':
    case 'admin-physical-review':
    case 'admin-certificate-review':
    case 'admin-police-review':
    case 'admin-interview-review':
    case 'admin-psych-review':
    case 'admin-caregiver-verification':
    case 'admin-agency-verification':
    case 'admin-disputes':
    case 'admin-cv-pool':
    case 'admin-tickets':
    case 'admin-analytics':
    case 'admin-settings':
    case 'admin-locked-accounts':
    case 'admin-manual-unlock':
    case 'admin-messages':
    case 'admin-billing':
      return <PlaceholderPage pageName={`Admin - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== SHOP ADMIN PAGES ====================
    case 'shop-registration':
    case 'shop-pending-verification':
    case 'shop-dashboard':
    case 'shop-products':
    case 'shop-add-product':
    case 'shop-orders':
    case 'shop-order-detail':
    case 'shop-update-status':
    case 'shop-messages':
    case 'shop-analytics':
    case 'shop-billing':
    case 'shop-payment-reminder':
    case 'shop-payment-warning':
    case 'shop-payment-final-warning':
    case 'shop-account-locked':
      return <PlaceholderPage pageName={`Shop Admin - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== SHOP MANAGER PAGES ====================
    case 'shop-manager-login':
    case 'shop-manager-dashboard':
    case 'shop-manager-orders':
    case 'shop-manager-order-detail':
    case 'shop-manager-inventory':
    case 'shop-manager-update-stock':
    case 'shop-manager-alerts':
    case 'shop-manager-inquiries':
    case 'shop-manager-chat':
    case 'shop-manager-restrictions':
      return <PlaceholderPage pageName={`Shop Manager - ${currentPage}`} onNavigate={onNavigate} />;

    // ==================== DEFAULT ====================
    default:
      return <NotFound onNavigateHome={() => onNavigate?.('toc')} onNavigateBack={() => onNavigate?.('toc')} />;
  }
}