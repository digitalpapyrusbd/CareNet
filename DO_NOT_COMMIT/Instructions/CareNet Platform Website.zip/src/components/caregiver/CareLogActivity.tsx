import { X, Mic, Camera, Image, FileText } from 'lucide-react';
import { useState } from 'react';

interface CareLogActivityProps {
  onClose: () => void;
  onSave: (activity: { type: string; notes: string; hasPhoto: boolean; hasVoice: boolean }) => void;
  patientName?: string;
}

export function CareLogActivity({ 
  onClose, 
  onSave, 
  patientName = 'Mrs. Begum' 
}: CareLogActivityProps) {
  const [activityType, setActivityType] = useState('');
  const [notes, setNotes] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [hasVoiceNote, setHasVoiceNote] = useState(false);
  const [hasPhoto, setHasPhoto] = useState(false);
  const [language, setLanguage] = useState<'en' | 'bn'>('en');

  const activityTypes = [
    { id: 'meal', label: 'Meal/Food Intake', icon: '🍽️' },
    { id: 'exercise', label: 'Physical Exercise', icon: '🏃' },
    { id: 'bathroom', label: 'Bathroom Assistance', icon: '🚽' },
    { id: 'hygiene', label: 'Personal Hygiene', icon: '🧼' },
    { id: 'mobility', label: 'Mobility Support', icon: '🚶' },
    { id: 'social', label: 'Social Activity', icon: '👥' },
    { id: 'entertainment', label: 'Entertainment/Recreation', icon: '📺' },
    { id: 'sleep', label: 'Rest/Sleep', icon: '😴' },
    { id: 'therapy', label: 'Therapy Session', icon: '💆' },
    { id: 'other', label: 'Other Activity', icon: '📝' }
  ];

  const handleVoiceRecord = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Simulate voice recording
      setTimeout(() => {
        setIsRecording(false);
        setHasVoiceNote(true);
        setNotes(prev => prev + (prev ? ' ' : '') + '[Voice note: Patient had a good appetite at lunch and ate well.]');
      }, 2000);
    }
  };

  const handleSave = () => {
    if (activityType && notes.trim()) {
      onSave({
        type: activityType,
        notes: notes.trim(),
        hasPhoto,
        hasVoice: hasVoiceNote
      });
      onClose();
    }
  };

  const canSave = activityType && notes.trim().length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Bottom Sheet */}
      <div 
        className="relative w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 max-h-[90vh] overflow-y-auto"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.85) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          boxShadow: '0 -4px 24px rgba(0, 0, 0, 0.1), 0 8px 32px rgba(0, 0, 0, 0.1)'
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl mb-1" style={{ color: '#535353' }}>Activity Note</h2>
            <p className="text-sm" style={{ color: '#848484' }}>{patientName}</p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0, 0, 0, 0.05)' }}
          >
            <X className="w-5 h-5" style={{ color: '#535353' }} />
          </button>
        </div>

        {/* Activity Type Selection */}
        <div className="mb-6">
          <label className="block mb-3" style={{ color: '#535353' }}>
            Activity Type
          </label>
          <div className="grid grid-cols-2 gap-2">
            {activityTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setActivityType(type.id)}
                className="p-3 rounded-xl text-left transition-all hover:scale-105"
                style={{
                  background: activityType === type.id
                    ? 'linear-gradient(135deg, #5B9FFF 0%, #4A8FEF 100%)'
                    : 'rgba(255, 255, 255, 0.6)',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  color: activityType === type.id ? '#FFFFFF' : '#535353'
                }}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{type.icon}</span>
                  <span className="text-sm">{type.label}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Language Toggle */}
        <div className="mb-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLanguage('en')}
              className="px-4 py-2 rounded-lg text-sm transition-all"
              style={{
                background: language === 'en' 
                  ? 'linear-gradient(135deg, #FFB547 0%, #FF9F47 100%)'
                  : 'rgba(255, 255, 255, 0.6)',
                color: language === 'en' ? '#FFFFFF' : '#535353'
              }}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('bn')}
              className="px-4 py-2 rounded-lg text-sm transition-all"
              style={{
                background: language === 'bn' 
                  ? 'linear-gradient(135deg, #FFB547 0%, #FF9F47 100%)'
                  : 'rgba(255, 255, 255, 0.6)',
                color: language === 'bn' ? '#FFFFFF' : '#535353'
              }}
            >
              বাংলা
            </button>
          </div>
        </div>

        {/* Notes Text Area */}
        <div className="mb-4">
          <label className="block mb-3" style={{ color: '#535353' }}>
            Activity Notes
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder={language === 'en' 
              ? 'Describe the activity in detail...'
              : 'কার্যকলাপের বিস্তারিত বর্ণনা করুন...'
            }
            rows={5}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353',
              resize: 'none'
            }}
          />
          <p className="text-xs mt-2" style={{ color: '#A0A0A0' }}>
            {notes.length} characters
          </p>
        </div>

        {/* Voice Input */}
        <div className="mb-4">
          <button
            onClick={handleVoiceRecord}
            className="w-full p-4 rounded-xl flex items-center justify-between transition-all hover:scale-105"
            style={{
              background: isRecording 
                ? 'linear-gradient(135deg, #FF6B6B 0%, #FF9F47 100%)'
                : hasVoiceNote
                ? 'linear-gradient(135deg, #7CE577 0%, #6BD468 100%)'
                : 'rgba(255, 255, 255, 0.6)',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
          >
            <div className="flex items-center gap-3">
              <Mic className="w-5 h-5" style={{ color: isRecording || hasVoiceNote ? '#FFFFFF' : '#535353' }} />
              <div className="text-left">
                <p style={{ color: isRecording || hasVoiceNote ? '#FFFFFF' : '#535353' }}>
                  {isRecording ? 'Recording...' : hasVoiceNote ? 'Voice Note Added' : 'Voice Input'}
                </p>
                <p className="text-xs" style={{ color: isRecording || hasVoiceNote ? 'rgba(255,255,255,0.8)' : '#848484' }}>
                  {language === 'en' ? 'Tap to record' : 'রেকর্ড করতে ট্যাপ করুন'}
                </p>
              </div>
            </div>
            {isRecording && (
              <div className="flex gap-1">
                <div className="w-1 h-4 bg-white rounded-full animate-pulse" />
                <div className="w-1 h-4 bg-white rounded-full animate-pulse delay-75" />
                <div className="w-1 h-4 bg-white rounded-full animate-pulse delay-150" />
              </div>
            )}
          </button>
        </div>

        {/* Photo Upload */}
        <div className="mb-6">
          <button
            onClick={() => setHasPhoto(!hasPhoto)}
            className="w-full p-4 rounded-xl flex items-center justify-between transition-all hover:scale-105"
            style={{
              background: hasPhoto
                ? 'linear-gradient(135deg, #7CE577 0%, #6BD468 100%)'
                : 'rgba(255, 255, 255, 0.6)',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
          >
            <div className="flex items-center gap-3">
              <Camera className="w-5 h-5" style={{ color: hasPhoto ? '#FFFFFF' : '#535353' }} />
              <div className="text-left">
                <p style={{ color: hasPhoto ? '#FFFFFF' : '#535353' }}>
                  {hasPhoto ? 'Photo Added' : 'Add Photo'}
                </p>
                <p className="text-xs" style={{ color: hasPhoto ? 'rgba(255,255,255,0.8)' : '#848484' }}>
                  Optional documentation
                </p>
              </div>
            </div>
            {hasPhoto && <Image className="w-5 h-5 text-white" />}
          </button>
        </div>

        {/* AI Transcription Preview */}
        {hasVoiceNote && (
          <div
            className="rounded-2xl p-4 mb-6"
            style={{
              background: 'rgba(91, 159, 255, 0.1)',
              border: '1px solid rgba(91, 159, 255, 0.2)'
            }}
          >
            <div className="flex items-start gap-2 mb-2">
              <FileText className="w-4 h-4 mt-1" style={{ color: '#5B9FFF' }} />
              <p className="text-xs font-medium" style={{ color: '#5B9FFF' }}>
                AI Transcription Preview
              </p>
            </div>
            <p className="text-sm" style={{ color: '#535353' }}>
              Voice note has been transcribed and added to notes
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onClose}
            className="py-3 rounded-xl font-medium transition-all"
            style={{
              background: 'rgba(0, 0, 0, 0.05)',
              color: '#535353'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="py-3 rounded-xl text-white font-medium transition-all hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
            style={{
              background: canSave 
                ? 'linear-gradient(135deg, #5B9FFF 0%, #4A8FEF 100%)'
                : 'rgba(0, 0, 0, 0.2)'
            }}
          >
            Save Activity
          </button>
        </div>
      </div>
    </div>
  );
}

export default CareLogActivity;
