import { VerificationPsychTest } from './VerificationPsychTest';

// Alternative page for psychological verification
export function VerificationPsych(props: any) {
  return <VerificationPsychTest {...props} />;
}
