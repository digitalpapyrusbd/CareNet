import { CheckOutFlow } from './CheckOutFlow';

// Alternative check-out page
export function CheckOutAlt(props: any) {
  return <CheckOutFlow {...props} />;
}
