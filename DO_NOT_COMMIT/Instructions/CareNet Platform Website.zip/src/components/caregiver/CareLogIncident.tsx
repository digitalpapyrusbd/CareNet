import { X, AlertTriangle, Camera, FileText, Send } from 'lucide-react';
import { useState } from 'react';

interface CareLogIncidentProps {
  onClose: () => void;
  onSave: (incident: { type: string; severity: string; description: string; actionTaken: string; hasMedia: boolean }) => void;
  patientName?: string;
}

export function CareLogIncident({ 
  onClose, 
  onSave, 
  patientName = 'Mrs. Begum' 
}: CareLogIncidentProps) {
  const [incidentType, setIncidentType] = useState('');
  const [severity, setSeverity] = useState('');
  const [description, setDescription] = useState('');
  const [actionTaken, setActionTaken] = useState('');
  const [hasMedia, setHasMedia] = useState(false);

  const incidentTypes = [
    { id: 'fall', label: 'Fall', icon: '🚨' },
    { id: 'emergency', label: 'Medical Emergency', icon: '⚕️' },
    { id: 'behavioral', label: 'Behavioral Issue', icon: '😤' },
    { id: 'equipment', label: 'Equipment Failure', icon: '⚠️' },
    { id: 'medication', label: 'Medication Error', icon: '💊' },
    { id: 'other', label: 'Other Incident', icon: '📝' }
  ];

  const severityLevels = [
    { id: 'low', label: 'Low', color: '#7CE577', desc: 'Minor, no immediate action needed' },
    { id: 'medium', label: 'Medium', color: '#FFB547', desc: 'Requires monitoring' },
    { id: 'high', label: 'High', color: '#FF9F47', desc: 'Immediate attention required' },
    { id: 'critical', label: 'Critical', color: '#FF6B6B', desc: 'Emergency - notify immediately' }
  ];

  const handleSave = () => {
    if (incidentType && severity && description.trim() && actionTaken.trim()) {
      const incident = {
        type: incidentType,
        severity,
        description: description.trim(),
        actionTaken: actionTaken.trim(),
        hasMedia
      };
      
      // Auto-notify for High/Critical incidents
      if (severity === 'high' || severity === 'critical') {
        // Show notification sent message
        setTimeout(() => {
          alert('⚠️ Immediate notification sent to Guardian and Agency');
        }, 500);
      }
      
      onSave(incident);
      onClose();
    }
  };

  const canSave = incidentType && severity && description.trim() && actionTaken.trim();

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Bottom Sheet */}
      <div 
        className="relative w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 max-h-[90vh] overflow-y-auto"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.85) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          boxShadow: '0 -4px 24px rgba(0, 0, 0, 0.1), 0 8px 32px rgba(0, 0, 0, 0.1)'
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl mb-1 flex items-center gap-2" style={{ color: '#FF6B6B' }}>
              <AlertTriangle className="w-6 h-6" />
              Report Incident
            </h2>
            <p className="text-sm" style={{ color: '#848484' }}>{patientName}</p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0, 0, 0, 0.05)' }}
          >
            <X className="w-5 h-5" style={{ color: '#535353' }} />
          </button>
        </div>

        {/* Warning Notice */}
        <div
          className="rounded-2xl p-4 mb-6"
          style={{
            background: 'rgba(255, 107, 107, 0.1)',
            border: '1px solid rgba(255, 107, 107, 0.3)'
          }}
        >
          <p className="text-sm" style={{ color: '#FF6B6B' }}>
            ⚠️ High and Critical incidents will immediately notify Guardian and Agency
          </p>
        </div>

        {/* Incident Type */}
        <div className="mb-6">
          <label className="block mb-3 font-medium" style={{ color: '#535353' }}>
            Incident Type *
          </label>
          <div className="grid grid-cols-2 gap-2">
            {incidentTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setIncidentType(type.id)}
                className="p-3 rounded-xl text-left transition-all hover:scale-105"
                style={{
                  background: incidentType === type.id
                    ? 'linear-gradient(135deg, #FF6B6B 0%, #FF9F47 100%)'
                    : 'rgba(255, 255, 255, 0.6)',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  color: incidentType === type.id ? '#FFFFFF' : '#535353'
                }}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{type.icon}</span>
                  <span className="text-sm">{type.label}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Severity Level */}
        <div className="mb-6">
          <label className="block mb-3 font-medium" style={{ color: '#535353' }}>
            Severity Level *
          </label>
          <div className="space-y-2">
            {severityLevels.map((level) => (
              <button
                key={level.id}
                onClick={() => setSeverity(level.id)}
                className="w-full p-4 rounded-xl text-left transition-all hover:scale-105"
                style={{
                  background: severity === level.id
                    ? `linear-gradient(135deg, ${level.color} 0%, ${level.color}DD 100%)`
                    : 'rgba(255, 255, 255, 0.6)',
                  border: `2px solid ${severity === level.id ? level.color : 'rgba(255, 255, 255, 0.3)'}`,
                  color: severity === level.id ? '#FFFFFF' : '#535353'
                }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium mb-1">{level.label}</p>
                    <p className="text-xs" style={{ 
                      color: severity === level.id ? 'rgba(255,255,255,0.9)' : '#848484' 
                    }}>
                      {level.desc}
                    </p>
                  </div>
                  {severity === level.id && (
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center"
                      style={{ background: 'rgba(255, 255, 255, 0.3)' }}
                    >
                      <span className="text-lg">✓</span>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Description */}
        <div className="mb-4">
          <label className="block mb-3 font-medium" style={{ color: '#535353' }}>
            Incident Description *
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Provide detailed description of what happened..."
            rows={4}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353',
              resize: 'none'
            }}
          />
        </div>

        {/* Action Taken */}
        <div className="mb-6">
          <label className="block mb-3 font-medium" style={{ color: '#535353' }}>
            Action Taken *
          </label>
          <textarea
            value={actionTaken}
            onChange={(e) => setActionTaken(e.target.value)}
            placeholder="Describe the immediate actions you took..."
            rows={3}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353',
              resize: 'none'
            }}
          />
        </div>

        {/* Photo/Video Upload */}
        <div className="mb-6">
          <button
            onClick={() => setHasMedia(!hasMedia)}
            className="w-full p-4 rounded-xl flex items-center justify-between transition-all hover:scale-105"
            style={{
              background: hasMedia
                ? 'linear-gradient(135deg, #5B9FFF 0%, #4A8FEF 100%)'
                : 'rgba(255, 255, 255, 0.6)',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
          >
            <div className="flex items-center gap-3">
              <Camera className="w-5 h-5" style={{ color: hasMedia ? '#FFFFFF' : '#535353' }} />
              <div className="text-left">
                <p style={{ color: hasMedia ? '#FFFFFF' : '#535353' }}>
                  {hasMedia ? 'Photo/Video Added' : 'Add Photo/Video Evidence'}
                </p>
                <p className="text-xs" style={{ color: hasMedia ? 'rgba(255,255,255,0.8)' : '#848484' }}>
                  Recommended for documentation
                </p>
              </div>
            </div>
            {hasMedia && <FileText className="w-5 h-5 text-white" />}
          </button>
        </div>

        {/* Auto-notification notice for high/critical */}
        {(severity === 'high' || severity === 'critical') && (
          <div
            className="rounded-2xl p-4 mb-6"
            style={{
              background: 'rgba(255, 107, 107, 0.15)',
              border: '1px solid rgba(255, 107, 107, 0.3)'
            }}
          >
            <div className="flex items-start gap-3">
              <Send className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#FF6B6B' }} />
              <div>
                <p className="font-medium mb-1" style={{ color: '#FF6B6B' }}>
                  Immediate Notification
                </p>
                <p className="text-xs" style={{ color: '#848484' }}>
                  This incident will immediately notify Guardian, Agency, and Platform Support
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onClose}
            className="py-3 rounded-xl font-medium transition-all"
            style={{
              background: 'rgba(0, 0, 0, 0.05)',
              color: '#535353'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="py-3 rounded-xl text-white font-medium transition-all hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
            style={{
              background: canSave 
                ? 'linear-gradient(135deg, #FF6B6B 0%, #FF9F47 100%)'
                : 'rgba(0, 0, 0, 0.2)'
            }}
          >
            Report Incident
          </button>
        </div>

        <p className="text-xs text-center mt-3" style={{ color: '#A0A0A0' }}>
          * All fields are required for incident reports
        </p>
      </div>
    </div>
  );
}

export default CareLogIncident;
