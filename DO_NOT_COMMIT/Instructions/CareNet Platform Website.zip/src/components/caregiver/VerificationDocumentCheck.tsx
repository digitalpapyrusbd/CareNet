import { ArrowLeft, FileCheck, CheckCircle, Clock } from 'lucide-react';
import { Button } from '../ui/button';

interface VerificationDocumentCheckProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

export function VerificationDocumentCheck({ onNavigate, onBack }: VerificationDocumentCheckProps) {
  const documents = [
    { name: 'NID Verification', status: 'verified' },
    { name: 'Certificates', status: 'verified' },
    { name: 'Police Clearance', status: 'pending' },
    { name: 'Medical Certificate', status: 'verified' },
  ];

  return (
    <div className="min-h-screen flex flex-col p-6">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-6 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full mb-4 animate-pulse"
            style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)', boxShadow: '0px 4px 18px rgba(240, 161, 180, 0.4)' }}>
            <FileCheck className="w-10 h-10 text-white" />
          </div>
          <h1 className="mb-2" style={{ color: '#535353' }}>Final Document Check</h1>
          <p style={{ color: '#848484' }}>Verifying All Documents</p>
        </div>
      </div>

      <div className="flex-1 space-y-4">
        <div className="finance-card p-5 mb-4" style={{ background: 'rgba(254, 180, 197, 0.1)' }}>
          <p className="text-center" style={{ color: '#535353' }}>
            Our team is performing a final verification of all your submitted documents.
          </p>
        </div>

        {documents.map((doc, idx) => (
          <div key={idx} className="finance-card p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {doc.status === 'verified' ? (
                  <CheckCircle className="w-6 h-6" style={{ color: '#7CE577' }} />
                ) : (
                  <Clock className="w-6 h-6 animate-pulse" style={{ color: '#FEB4C5' }} />
                )}
                <div>
                  <p style={{ color: '#535353' }}>{doc.name}</p>
                  <p className="text-xs" style={{ color: '#848484' }}>
                    {doc.status === 'verified' ? 'Verified' : 'Under Review'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Button onClick={() => onNavigate?.('caregiver-pending-verification')} variant="outline" className="w-full py-6 mt-6"
        style={{ color: '#535353', borderColor: 'rgba(132, 132, 132, 0.2)' }}>
        Back to Verification Status
      </Button>
    </div>
  );
}
