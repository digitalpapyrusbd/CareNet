import { ArrowLeft, Activity, Clock } from 'lucide-react';
import { Button } from '../ui/button';

interface CareLogActivitiesListProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const ACTIVITIES_LOG = [
  { time: '9:30 AM', activity: 'Breakfast', notes: 'Patient ate well - 80% of meal completed', photo: true },
  { time: '10:15 AM', activity: 'Personal Hygiene', notes: 'Assisted with bathing and dressing', photo: false },
  { time: '11:00 AM', activity: 'Light Exercise', notes: 'Completed 15 minutes of seated exercises', photo: false },
  { time: '12:30 PM', activity: 'Vital Signs Check', notes: 'BP: 130/85, Temp: 98.2°F, All normal', photo: false }
];

export function CareLogActivitiesList({ onNavigate, onBack }: CareLogActivitiesListProps) {
  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      <div className="finance-card p-6 mb-4">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-4 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 style={{ color: '#535353' }}>Today's Activities</h1>
        <p style={{ color: '#848484' }}>Activity and care log</p>
      </div>

      <div className="px-6 space-y-3">
        {ACTIVITIES_LOG.map((activity, idx) => (
          <div key={idx} className="finance-card p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                style={{ background: 'rgba(155, 156, 248, 0.2)' }}>
                <Activity className="w-5 h-5" style={{ color: '#9B9CF8' }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h3 style={{ color: '#535353' }}>{activity.activity}</h3>
                  {activity.photo && (
                    <span className="text-xs px-2 py-1 rounded-full" style={{ background: 'rgba(254, 180, 197, 0.2)', color: '#FEB4C5' }}>
                      📷 Photo
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4" style={{ color: '#848484' }} />
                  <span className="text-sm" style={{ color: '#848484' }}>{activity.time}</span>
                </div>
                <p className="text-sm" style={{ color: '#848484' }}>{activity.notes}</p>
              </div>
            </div>
          </div>
        ))}

        <Button onClick={() => onNavigate?.('caregiver-log-activity')} className="w-full py-4 mt-4"
          style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)', color: 'white' }}>
          Add New Activity
        </Button>
      </div>
    </div>
  );
}
