import { ArrowLeft, DollarSign, CreditCard, Building2 } from 'lucide-react';
import { Button } from '../ui/button';
import { useState } from 'react';

interface EarningsWithdrawProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

export function EarningsWithdraw({ onNavigate, onBack }: EarningsWithdrawProps) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'bank' | 'mobile'>('mobile');

  const availableBalance = 32400;

  return (
    <div className="min-h-screen flex flex-col p-6">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-6 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <h1 className="mb-2" style={{ color: '#535353' }}>Withdraw Earnings</h1>
        <p style={{ color: '#848484' }}>Transfer your earnings to your account</p>
      </div>

      <div className="flex-1 space-y-6">
        {/* Available Balance */}
        <div className="finance-card p-6 text-center">
          <p className="text-sm mb-2" style={{ color: '#848484' }}>Available Balance</p>
          <p className="text-4xl" style={{ color: '#7CE577' }}>৳{availableBalance.toLocaleString()}</p>
        </div>

        {/* Withdrawal Amount */}
        <div>
          <label className="block mb-2 text-sm" style={{ color: '#535353' }}>Withdrawal Amount</label>
          <div className="relative">
            <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount" className="w-full finance-card px-4 py-4 pl-12 text-xl"
              style={{ color: '#535353', outline: 'none' }} />
            <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6" style={{ color: '#848484' }} />
          </div>
          <p className="text-xs mt-2" style={{ color: '#848484' }}>Minimum withdrawal: ৳1,000</p>
        </div>

        {/* Withdrawal Method */}
        <div>
          <label className="block mb-3 text-sm" style={{ color: '#535353' }}>Withdrawal Method</label>
          <div className="space-y-3">
            <button onClick={() => setMethod('mobile')}
              className={`w-full finance-card p-4 flex items-center gap-3 transition-all ${method === 'mobile' ? 'ring-2' : ''}`}
              style={{ borderColor: method === 'mobile' ? '#FEB4C5' : 'transparent' }}>
              <div className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(254, 180, 197, 0.2)' }}>
                <CreditCard className="w-6 h-6" style={{ color: '#FEB4C5' }} />
              </div>
              <div className="text-left flex-1">
                <p style={{ color: '#535353' }}>Mobile Banking</p>
                <p className="text-sm" style={{ color: '#848484' }}>bKash, Nagad, Rocket</p>
              </div>
            </button>

            <button onClick={() => setMethod('bank')}
              className={`w-full finance-card p-4 flex items-center gap-3 transition-all ${method === 'bank' ? 'ring-2' : ''}`}
              style={{ borderColor: method === 'bank' ? '#FEB4C5' : 'transparent' }}>
              <div className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(155, 156, 248, 0.2)' }}>
                <Building2 className="w-6 h-6" style={{ color: '#9B9CF8' }} />
              </div>
              <div className="text-left flex-1">
                <p style={{ color: '#535353' }}>Bank Transfer</p>
                <p className="text-sm" style={{ color: '#848484' }}>2-3 business days</p>
              </div>
            </button>
          </div>
        </div>

        {/* Account Details (if mobile) */}
        {method === 'mobile' && (
          <div>
            <label className="block mb-2 text-sm" style={{ color: '#535353' }}>Mobile Number</label>
            <input type="tel" placeholder="+880 1712-345678" className="w-full finance-card px-4 py-3"
              style={{ color: '#535353', outline: 'none' }} />
          </div>
        )}

        {/* Info */}
        <div className="finance-card p-4" style={{ background: 'rgba(254, 180, 197, 0.1)' }}>
          <p className="text-sm" style={{ color: '#848484' }}>
            💡 Withdrawals are processed within 24-48 hours. A 2% processing fee applies.
          </p>
        </div>
      </div>

      <Button onClick={() => onNavigate?.('caregiver-earnings')}
        disabled={!amount || parseInt(amount) < 1000 || parseInt(amount) > availableBalance}
        className="w-full py-6 mt-6"
        style={{
          background: (!amount || parseInt(amount) < 1000 || parseInt(amount) > availableBalance)
            ? 'rgba(132, 132, 132, 0.3)'
            : 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #7CE577 0%, #5FB865 100%)',
          color: 'white',
          cursor: (!amount || parseInt(amount) < 1000 || parseInt(amount) > availableBalance) ? 'not-allowed' : 'pointer'
        }}>
        Confirm Withdrawal
      </Button>
    </div>
  );
}
