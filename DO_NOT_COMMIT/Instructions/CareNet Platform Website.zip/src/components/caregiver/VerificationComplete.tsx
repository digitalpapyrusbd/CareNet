import { CheckCircle, Sparkles, Award } from 'lucide-react';
import { Button } from '../ui/button';

interface VerificationCompleteProps {
  onNavigate?: (page: string) => void;
}

export function VerificationComplete({ onNavigate }: VerificationCompleteProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="text-center max-w-md">
        <div className="relative inline-block mb-6">
          <div className="inline-flex items-center justify-center w-32 h-32 rounded-full animate-bounce"
            style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #7CE577 0%, #5FB865 100%)', boxShadow: '0px 8px 32px rgba(124, 229, 119, 0.4)' }}>
            <CheckCircle className="w-16 h-16 text-white" />
          </div>
          <Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-yellow-400 animate-pulse" />
          <Sparkles className="absolute -bottom-2 -left-2 w-6 h-6 text-yellow-400 animate-pulse delay-100" />
        </div>

        <h1 className="mb-4" style={{ color: '#535353' }}>🎉 Verification Complete!</h1>
        <p className="text-lg mb-8" style={{ color: '#848484' }}>
          Congratulations! You are now a verified CareNet caregiver.
        </p>

        <div className="finance-card p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <Award className="w-8 h-8" style={{ color: '#FEB4C5' }} />
            <div className="text-left">
              <p style={{ color: '#535353' }}>Verification Badge Unlocked</p>
              <p className="text-sm" style={{ color: '#848484' }}>You can now accept job offers</p>
            </div>
          </div>
          <div className="space-y-2 text-left">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5" style={{ color: '#7CE577' }} />
              <span className="text-sm" style={{ color: '#535353' }}>All documents verified</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5" style={{ color: '#7CE577' }} />
              <span className="text-sm" style={{ color: '#535353' }}>Background check passed</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5" style={{ color: '#7CE577' }} />
              <span className="text-sm" style={{ color: '#535353' }}>Assessments completed</span>
            </div>
          </div>
        </div>

        <div className="finance-card p-5 mb-8" style={{ background: 'rgba(254, 180, 197, 0.1)' }}>
          <p className="text-sm" style={{ color: '#535353' }}>
            <strong>What's Next?</strong>
          </p>
          <ul className="text-sm mt-3 space-y-2 text-left" style={{ color: '#848484' }}>
            <li>✓ Subscribe to start receiving job offers</li>
            <li>✓ Complete your availability calendar</li>
            <li>✓ Set up your payment information</li>
          </ul>
        </div>

        <Button onClick={() => onNavigate?.('caregiver-subscription')} className="w-full py-6"
          style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)', color: 'white', boxShadow: '0px 4px 18px rgba(240, 161, 180, 0.4)' }}>
          View Subscription Plans
        </Button>

        <Button onClick={() => onNavigate?.('caregiver-home')} variant="ghost" className="w-full py-4 mt-3" style={{ color: '#848484' }}>
          Go to Dashboard
        </Button>
      </div>
    </div>
  );
}
