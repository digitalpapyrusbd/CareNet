import { Phone, AlertCircle, MapPin, User, FileText } from 'lucide-react';
import { Button } from '../ui/button';

interface EmergencyProps {
  onNavigate?: (page: string) => void;
}

const EMERGENCY_CONTACTS = [
  { name: 'Platform Emergency Hotline', number: '999', type: 'platform', color: '#FF6B6B' },
  { name: 'Guardian: Sadia Rahman', number: '+880 1712-345678', type: 'guardian', color: '#FEB4C5' },
  { name: 'Patient Doctor: Dr. Ahmed', number: '+880 1812-345678', type: 'doctor', color: '#9B9CF8' },
  { name: 'Nearest Hospital', number: '102', type: 'hospital', color: '#7CE577' }
];

export function Emergency({ onNavigate }: EmergencyProps) {
  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: '#F5F7FA' }}>
      {/* Alert Header */}
      <div className="finance-card p-6 mb-6 text-center" style={{ background: 'rgba(255, 107, 107, 0.1)' }}>
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full mb-4 animate-pulse"
          style={{ background: '#FF6B6B' }}>
          <AlertCircle className="w-10 h-10 text-white" />
        </div>
        <h1 className="mb-2" style={{ color: '#FF6B6B' }}>Emergency Protocol</h1>
        <p style={{ color: '#848484' }}>Quick access to emergency contacts</p>
      </div>

      {/* Current Job Info */}
      <div className="finance-card p-5 mb-4">
        <p className="text-sm mb-3" style={{ color: '#535353' }}><strong>Current Assignment:</strong></p>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5" style={{ color: '#848484' }} />
            <span style={{ color: '#535353' }}>Mrs. Fatima Rahman (72)</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5" style={{ color: '#848484' }} />
            <span className="text-sm" style={{ color: '#535353' }}>House 45, Road 12, Dhanmondi, Dhaka</span>
          </div>
        </div>
      </div>

      {/* Emergency Contacts */}
      <div className="space-y-3 mb-6">
        {EMERGENCY_CONTACTS.map((contact, idx) => (
          <a key={idx} href={`tel:${contact.number}`} className="block">
            <div className="finance-card p-5">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0"
                  style={{ background: `${contact.color}20` }}>
                  <Phone className="w-6 h-6" style={{ color: contact.color }} />
                </div>
                <div className="flex-1">
                  <h3 style={{ color: '#535353' }}>{contact.name}</h3>
                  <p className="text-sm" style={{ color: contact.color }}>{contact.number}</p>
                </div>
                <div className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{ background: `${contact.color}20` }}>
                  <span style={{ color: contact.color }}>→</span>
                </div>
              </div>
            </div>
          </a>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="space-y-3">
        <Button onClick={() => onNavigate?.('caregiver-log-incident')} className="w-full py-4"
          style={{ background: '#FF6B6B', color: 'white' }}>
          <FileText className="w-5 h-5 mr-2" />
          Report Incident
        </Button>

        <Button onClick={() => onNavigate?.('caregiver-home')} variant="outline" className="w-full py-4"
          style={{ color: '#535353', borderColor: 'rgba(132, 132, 132, 0.2)' }}>
          Back to Dashboard
        </Button>
      </div>

      {/* Instructions */}
      <div className="finance-card p-5 mt-6" style={{ background: 'rgba(255, 107, 107, 0.1)' }}>
        <p className="text-sm mb-2" style={{ color: '#535353' }}><strong>⚠️ Emergency Protocol:</strong></p>
        <ol className="text-xs space-y-2" style={{ color: '#848484' }}>
          <li>1. Ensure patient safety first</li>
          <li>2. Call appropriate emergency number</li>
          <li>3. Notify guardian immediately</li>
          <li>4. Document incident in care logs</li>
          <li>5. Follow up with platform support</li>
        </ol>
      </div>
    </div>
  );
}
