import { ArrowLeft, Pill, Clock, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '../ui/button';

interface CareLogMedicationsListProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const MEDICATIONS_LOG = [
  { time: '9:00 AM', medication: 'Metformin 500mg', status: 'given', givenAt: '9:05 AM', notes: 'Taken with breakfast' },
  { time: '1:00 PM', medication: 'Amlodipine 5mg', status: 'skipped', reason: 'Patient refused - nausea' },
  { time: '8:00 PM', medication: 'Metformin 500mg', status: 'pending', givenAt: null, notes: null },
  { time: '9:00 PM', medication: 'Insulin 10 units', status: 'pending', givenAt: null, notes: null }
];

export function CareLogMedicationsList({ onNavigate, onBack }: CareLogMedicationsListProps) {
  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      <div className="finance-card p-6 mb-4">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-4 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 style={{ color: '#535353' }}>Today's Medications</h1>
        <p style={{ color: '#848484' }}>Track medication administration</p>
      </div>

      <div className="px-6 space-y-3">
        {MEDICATIONS_LOG.map((med, idx) => (
          <div key={idx} className="finance-card p-4"
            style={{ background: med.status === 'given' ? 'rgba(124, 229, 119, 0.05)' : med.status === 'skipped' ? 'rgba(255, 107, 107, 0.05)' : 'white' }}>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{ background: med.status === 'given' ? 'rgba(124, 229, 119, 0.2)' : med.status === 'skipped' ? 'rgba(255, 107, 107, 0.2)' : 'rgba(254, 180, 197, 0.2)' }}>
                  <Pill className="w-5 h-5"
                    style={{ color: med.status === 'given' ? '#7CE577' : med.status === 'skipped' ? '#FF6B6B' : '#FEB4C5' }} />
                </div>
                <div>
                  <h3 style={{ color: '#535353' }}>{med.medication}</h3>
                  <div className="flex items-center gap-2 text-sm" style={{ color: '#848484' }}>
                    <Clock className="w-4 h-4" />
                    <span>{med.time}</span>
                  </div>
                </div>
              </div>
              {med.status === 'given' && (
                <CheckCircle className="w-6 h-6" style={{ color: '#7CE577' }} />
              )}
              {med.status === 'skipped' && (
                <XCircle className="w-6 h-6" style={{ color: '#FF6B6B' }} />
              )}
            </div>

            {med.status === 'given' && med.notes && (
              <p className="text-sm pl-13" style={{ color: '#848484' }}>✓ {med.notes}</p>
            )}
            {med.status === 'skipped' && med.reason && (
              <p className="text-sm pl-13" style={{ color: '#FF6B6B' }}>⚠️ {med.reason}</p>
            )}
            {med.status === 'pending' && (
              <Button onClick={() => onNavigate?.('caregiver-log-medication')} className="w-full mt-2 py-2"
                style={{ background: 'rgba(254, 180, 197, 0.1)', color: '#FEB4C5' }}>
                Log Administration
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
