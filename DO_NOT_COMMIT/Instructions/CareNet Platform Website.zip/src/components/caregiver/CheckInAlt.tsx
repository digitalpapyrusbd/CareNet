import { CheckIn } from './CheckIn';

// Alternative check-in page
export function CheckInAlt(props: any) {
  return <CheckIn {...props} />;
}
