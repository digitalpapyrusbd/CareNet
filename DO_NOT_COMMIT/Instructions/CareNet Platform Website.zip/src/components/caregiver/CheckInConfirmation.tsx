import { CheckCircle2, MapPin, Clock, Camera, ArrowLeft } from 'lucide-react';
import { useState, useEffect } from 'react';

interface CheckInConfirmationProps {
  onStartCareSession: () => void;
  onNavigate?: (page: string) => void;
  patientName?: string;
  location?: string;
  hasPhoto?: boolean;
}

export function CheckInConfirmation({ 
  onStartCareSession,
  onNavigate,
  patientName = 'Mrs. Begum',
  location = 'House 12, Road 5, Dhanmondi, Dhaka',
  hasPhoto = true
}: CheckInConfirmationProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen p-6 flex flex-col items-center justify-center">
      {/* Success Animation */}
      <div className="mb-8">
        <div
          className="w-32 h-32 rounded-full mx-auto flex items-center justify-center animate-scale-in"
          style={{
            background: 'linear-gradient(135deg, #7CE577 0%, #6BD468 100%)',
            boxShadow: '0 8px 32px rgba(124, 229, 119, 0.4)'
          }}
        >
          <CheckCircle2 className="w-16 h-16 text-white" />
        </div>
      </div>

      {/* Success Message */}
      <h1 className="text-3xl text-center mb-2" style={{ color: '#535353' }}>
        Check-In Successful!
      </h1>
      <p className="text-center mb-8" style={{ color: '#848484' }}>
        You're all set to start the care session
      </p>

      {/* Check-In Details Card */}
      <div 
        className="w-full max-w-md rounded-3xl p-6 mb-6"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%)',
          backdropFilter: 'blur(10px)',
          WebkitBackdropFilter: 'blur(10px)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
          border: '1px solid rgba(255, 255, 255, 0.3)'
        }}
      >
        {/* Patient Name */}
        <div className="mb-6 text-center">
          <p className="text-sm mb-1" style={{ color: '#848484' }}>Care Session For</p>
          <h2 className="text-2xl" style={{ color: '#535353' }}>{patientName}</h2>
        </div>

        <div className="space-y-4">
          {/* Check-In Time */}
          <div 
            className="rounded-2xl p-4"
            style={{
              background: 'rgba(91, 159, 255, 0.1)',
              border: '1px solid rgba(91, 159, 255, 0.2)'
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(91, 159, 255, 0.2)' }}
              >
                <Clock className="w-6 h-6" style={{ color: '#5B9FFF' }} />
              </div>
              <div className="flex-1">
                <p className="text-xs mb-1" style={{ color: '#848484' }}>Check-In Time</p>
                <p className="font-medium" style={{ color: '#535353' }}>
                  {formatTime(currentTime)}
                </p>
                <p className="text-xs" style={{ color: '#A0A0A0' }}>
                  {formatDate(currentTime)}
                </p>
              </div>
            </div>
          </div>

          {/* Location Verified */}
          <div 
            className="rounded-2xl p-4"
            style={{
              background: 'rgba(124, 229, 119, 0.1)',
              border: '1px solid rgba(124, 229, 119, 0.2)'
            }}
          >
            <div className="flex items-start gap-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: 'rgba(124, 229, 119, 0.2)' }}
              >
                <MapPin className="w-6 h-6" style={{ color: '#7CE577' }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs" style={{ color: '#7CE577' }}>Location Verified</p>
                  <CheckCircle2 className="w-4 h-4" style={{ color: '#7CE577' }} />
                </div>
                <p className="text-sm" style={{ color: '#535353' }}>
                  {location}
                </p>
              </div>
            </div>
          </div>

          {/* Photo Confirmation */}
          {hasPhoto && (
            <div 
              className="rounded-2xl p-4"
              style={{
                background: 'rgba(255, 107, 157, 0.1)',
                border: '1px solid rgba(255, 107, 157, 0.2)'
              }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ background: 'rgba(255, 107, 157, 0.2)' }}
                >
                  <Camera className="w-6 h-6" style={{ color: '#FF6B9D' }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-xs" style={{ color: '#FF6B9D' }}>Arrival Photo Captured</p>
                    <CheckCircle2 className="w-4 h-4" style={{ color: '#FF6B9D' }} />
                  </div>
                  <p className="text-xs" style={{ color: '#A0A0A0' }}>
                    Timestamped and logged
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Start Care Session Button */}
      <button
        onClick={onStartCareSession}
        className="w-full max-w-md py-4 rounded-2xl text-white font-medium text-lg transition-all hover:scale-105 active:scale-95"
        style={{
          background: 'linear-gradient(135deg, #FF6B9D 0%, #FFA06B 100%)',
          boxShadow: '0 4px 16px rgba(255, 107, 157, 0.4)'
        }}
      >
        Start Care Session
      </button>

      {/* Info Note */}
      <p className="text-xs text-center mt-6 max-w-md" style={{ color: '#A0A0A0' }}>
        ✓ Attendance recorded • ✓ Guardian notified • ✓ Session timer started
      </p>

      <style>{`
        @keyframes scale-in {
          0% {
            transform: scale(0);
            opacity: 0;
          }
          50% {
            transform: scale(1.1);
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        .animate-scale-in {
          animation: scale-in 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
      `}</style>
    </div>
  );
}

export default CheckInConfirmation;