import { X, Pill, Camera, Clock, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { useState } from 'react';

interface Medication {
  id: string;
  name: string;
  dosage: string;
  time: string;
  status?: 'given' | 'skipped' | null;
  skipReason?: string;
}

interface CareLogMedicationProps {
  onClose: () => void;
  onSave: (medications: Medication[]) => void;
  patientName?: string;
}

export function CareLogMedication({ 
  onClose, 
  onSave, 
  patientName = 'Mrs. Begum' 
}: CareLogMedicationProps) {
  const [medications, setMedications] = useState<Medication[]>([
    {
      id: '1',
      name: 'Metformin 500mg',
      dosage: '1 tablet',
      time: '09:00 AM',
      status: null
    },
    {
      id: '2',
      name: 'Amlodipine 5mg',
      dosage: '1 tablet',
      time: '09:00 AM',
      status: null
    },
    {
      id: '3',
      name: 'Aspirin 75mg',
      dosage: '1 tablet',
      time: '09:00 AM',
      status: null
    }
  ]);

  const [showSkipReasonFor, setShowSkipReasonFor] = useState<string | null>(null);
  const [skipReason, setSkipReason] = useState('');
  const [photoTaken, setPhotoTaken] = useState(false);

  const handleStatusChange = (id: string, status: 'given' | 'skipped') => {
    if (status === 'skipped') {
      setShowSkipReasonFor(id);
    } else {
      setMedications(meds =>
        meds.map(med =>
          med.id === id ? { ...med, status, skipReason: undefined } : med
        )
      );
    }
  };

  const handleSkipReasonSave = () => {
    if (showSkipReasonFor && skipReason.trim()) {
      setMedications(meds =>
        meds.map(med =>
          med.id === showSkipReasonFor 
            ? { ...med, status: 'skipped' as const, skipReason } 
            : med
        )
      );
      setShowSkipReasonFor(null);
      setSkipReason('');
    }
  };

  const handleSave = () => {
    const completedMeds = medications.filter(med => med.status !== null);
    onSave(completedMeds);
    onClose();
  };

  const allMarked = medications.every(med => med.status !== null);
  const givenCount = medications.filter(med => med.status === 'given').length;
  const skippedCount = medications.filter(med => med.status === 'skipped').length;

  // Skip Reason Modal
  if (showSkipReasonFor) {
    return (
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
        <div 
          className="absolute inset-0 bg-black/30 backdrop-blur-sm"
          onClick={() => setShowSkipReasonFor(null)}
        />
        <div 
          className="relative w-full max-w-md rounded-3xl p-6"
          style={{
            background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.85) 100%)',
            backdropFilter: 'blur(20px)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
          }}
        >
          <h3 className="text-lg mb-4" style={{ color: '#535353' }}>
            Why was this medication skipped?
          </h3>
          <textarea
            value={skipReason}
            onChange={(e) => setSkipReason(e.target.value)}
            placeholder="Enter reason (required)..."
            rows={4}
            className="w-full px-4 py-3 rounded-xl outline-none mb-4"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353',
              resize: 'none'
            }}
          />
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                setShowSkipReasonFor(null);
                setSkipReason('');
              }}
              className="py-3 rounded-xl font-medium"
              style={{
                background: 'rgba(0, 0, 0, 0.05)',
                color: '#535353'
              }}
            >
              Cancel
            </button>
            <button
              onClick={handleSkipReasonSave}
              disabled={!skipReason.trim()}
              className="py-3 rounded-xl text-white font-medium disabled:opacity-50"
              style={{
                background: 'linear-gradient(135deg, #FFB547 0%, #FF9F47 100%)'
              }}
            >
              Confirm Skip
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Bottom Sheet */}
      <div 
        className="relative w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 max-h-[90vh] overflow-y-auto"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.85) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          boxShadow: '0 -4px 24px rgba(0, 0, 0, 0.1), 0 8px 32px rgba(0, 0, 0, 0.1)'
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl mb-1" style={{ color: '#535353' }}>Medication Log</h2>
            <p className="text-sm" style={{ color: '#848484' }}>{patientName}</p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0, 0, 0, 0.05)' }}
          >
            <X className="w-5 h-5" style={{ color: '#535353' }} />
          </button>
        </div>

        {/* Progress Summary */}
        {medications.some(med => med.status !== null) && (
          <div
            className="rounded-2xl p-4 mb-6"
            style={{
              background: 'rgba(91, 159, 255, 0.1)',
              border: '1px solid rgba(91, 159, 255, 0.2)'
            }}
          >
            <div className="flex items-center justify-around">
              <div className="text-center">
                <div className="text-2xl mb-1" style={{ color: '#7CE577' }}>{givenCount}</div>
                <div className="text-xs" style={{ color: '#848484' }}>Given</div>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-1" style={{ color: '#FFB547' }}>{skippedCount}</div>
                <div className="text-xs" style={{ color: '#848484' }}>Skipped</div>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-1" style={{ color: '#D3D3D3' }}>
                  {medications.length - givenCount - skippedCount}
                </div>
                <div className="text-xs" style={{ color: '#848484' }}>Pending</div>
              </div>
            </div>
          </div>
        )}

        {/* Scheduled Medications List */}
        <div className="space-y-3 mb-6">
          {medications.map((med) => (
            <div
              key={med.id}
              className="rounded-2xl p-4"
              style={{
                background: med.status === 'given'
                  ? 'rgba(124, 229, 119, 0.1)'
                  : med.status === 'skipped'
                  ? 'rgba(255, 181, 71, 0.1)'
                  : 'rgba(255, 255, 255, 0.6)',
                border: '1px solid rgba(255, 255, 255, 0.3)'
              }}
            >
              <div className="flex items-start gap-3 mb-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    background: 'linear-gradient(135deg, #FF6B9D20 0%, #FFA06B20 100%)'
                  }}
                >
                  <Pill className="w-5 h-5" style={{ color: '#FF6B9D' }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium mb-1" style={{ color: '#535353' }}>
                    {med.name}
                  </h3>
                  <div className="flex items-center gap-4 text-sm" style={{ color: '#848484' }}>
                    <span>{med.dosage}</span>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{med.time}</span>
                    </div>
                  </div>
                  {med.skipReason && (
                    <div className="mt-2 text-sm" style={{ color: '#FFB547' }}>
                      Reason: {med.skipReason}
                    </div>
                  )}
                </div>
              </div>

              {/* Status Buttons */}
              {med.status === null ? (
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleStatusChange(med.id, 'given')}
                    className="py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all hover:scale-105"
                    style={{
                      background: 'linear-gradient(135deg, #7CE577 0%, #6BD468 100%)',
                      color: 'white'
                    }}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Given
                  </button>
                  <button
                    onClick={() => handleStatusChange(med.id, 'skipped')}
                    className="py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all hover:scale-105"
                    style={{
                      background: 'linear-gradient(135deg, #FFB547 0%, #FF9F47 100%)',
                      color: 'white'
                    }}
                  >
                    <XCircle className="w-4 h-4" />
                    Skipped
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {med.status === 'given' ? (
                      <>
                        <CheckCircle2 className="w-5 h-5" style={{ color: '#7CE577' }} />
                        <span className="text-sm font-medium" style={{ color: '#7CE577' }}>
                          Medication Given
                        </span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5" style={{ color: '#FFB547' }} />
                        <span className="text-sm font-medium" style={{ color: '#FFB547' }}>
                          Skipped
                        </span>
                      </>
                    )}
                  </div>
                  <button
                    onClick={() => setMedications(meds =>
                      meds.map(m => m.id === med.id ? { ...m, status: null, skipReason: undefined } : m)
                    )}
                    className="text-xs underline"
                    style={{ color: '#848484' }}
                  >
                    Undo
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Photo Capture Option */}
        <div
          className="rounded-2xl p-4 mb-6"
          style={{
            background: 'rgba(255, 255, 255, 0.6)',
            border: '1px solid rgba(255, 255, 255, 0.3)'
          }}
        >
          <button
            onClick={() => setPhotoTaken(!photoTaken)}
            className="w-full flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <Camera className="w-5 h-5" style={{ color: '#5B9FFF' }} />
              <div className="text-left">
                <p style={{ color: '#535353' }}>Photo Evidence (Optional)</p>
                <p className="text-xs" style={{ color: '#848484' }}>
                  {photoTaken ? 'Photo captured' : 'Capture photo of medication given'}
                </p>
              </div>
            </div>
            {photoTaken && (
              <CheckCircle2 className="w-5 h-5" style={{ color: '#7CE577' }} />
            )}
          </button>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onClose}
            className="py-3 rounded-xl font-medium transition-all"
            style={{
              background: 'rgba(0, 0, 0, 0.05)',
              color: '#535353'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!allMarked}
            className="py-3 rounded-xl text-white font-medium transition-all hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
            style={{
              background: allMarked 
                ? 'linear-gradient(135deg, #5B9FFF 0%, #4A8FEF 100%)'
                : 'rgba(0, 0, 0, 0.2)'
            }}
          >
            Save Log
          </button>
        </div>

        {!allMarked && (
          <p className="text-xs text-center mt-3" style={{ color: '#FF6B6B' }}>
            Please mark all medications as given or skipped
          </p>
        )}
      </div>
    </div>
  );
}

export default CareLogMedication;
