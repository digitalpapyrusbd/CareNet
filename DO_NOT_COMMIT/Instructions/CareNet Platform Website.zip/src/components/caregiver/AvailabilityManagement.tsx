import { useState } from 'react';
import { ArrowLeft, Calendar, Clock, Save } from 'lucide-react';
import { Button } from '../ui/button';

interface AvailabilityManagementProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export function AvailabilityManagement({ onNavigate, onBack }: AvailabilityManagementProps) {
  const [availability, setAvailability] = useState<Record<string, { enabled: boolean; start: string; end: string }>>({
    Monday: { enabled: true, start: '09:00', end: '17:00' },
    Tuesday: { enabled: true, start: '09:00', end: '17:00' },
    Wednesday: { enabled: true, start: '09:00', end: '17:00' },
    Thursday: { enabled: true, start: '09:00', end: '17:00' },
    Friday: { enabled: true, start: '09:00', end: '17:00' },
    Saturday: { enabled: false, start: '09:00', end: '17:00' },
    Sunday: { enabled: false, start: '09:00', end: '17:00' }
  });

  const toggleDay = (day: string) => {
    setAvailability(prev => ({ ...prev, [day]: { ...prev[day], enabled: !prev[day].enabled } }));
  };

  const updateTime = (day: string, field: 'start' | 'end', value: string) => {
    setAvailability(prev => ({ ...prev, [day]: { ...prev[day], [field]: value } }));
  };

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      <div className="finance-card p-6 mb-4">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-4 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 style={{ color: '#535353' }}>Availability Management</h1>
        <p style={{ color: '#848484' }}>Set your weekly work schedule</p>
      </div>

      <div className="px-6 space-y-3">
        {DAYS.map(day => (
          <div key={day} className="finance-card p-4">
            <div className="flex items-center justify-between mb-3">
              <label className="flex items-center gap-3">
                <input type="checkbox" checked={availability[day].enabled} onChange={() => toggleDay(day)}
                  className="w-5 h-5 accent-pink-500" />
                <span style={{ color: '#535353' }}>{day}</span>
              </label>
            </div>

            {availability[day].enabled && (
              <div className="grid grid-cols-2 gap-3 pl-8">
                <div>
                  <label className="block text-xs mb-1" style={{ color: '#848484' }}>Start Time</label>
                  <div className="relative">
                    <input type="time" value={availability[day].start}
                      onChange={(e) => updateTime(day, 'start', e.target.value)}
                      className="w-full finance-card px-3 py-2 text-sm pr-8" style={{ color: '#535353', outline: 'none' }} />
                    <Clock className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#848484' }} />
                  </div>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: '#848484' }}>End Time</label>
                  <div className="relative">
                    <input type="time" value={availability[day].end}
                      onChange={(e) => updateTime(day, 'end', e.target.value)}
                      className="w-full finance-card px-3 py-2 text-sm pr-8" style={{ color: '#535353', outline: 'none' }} />
                    <Clock className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#848484' }} />
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="px-6 mt-6">
        <Button onClick={() => onNavigate?.('caregiver-home')} className="w-full py-6"
          style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)', color: 'white' }}>
          <Save className="w-5 h-5 mr-2" />
          Save Availability
        </Button>
      </div>
    </div>
  );
}
