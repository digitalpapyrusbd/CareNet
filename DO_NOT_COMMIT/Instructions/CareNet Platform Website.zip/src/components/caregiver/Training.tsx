import { ArrowLeft, GraduationCap, Play, CheckCircle, Clock, Award } from 'lucide-react';
import { Button } from '../ui/button';

interface TrainingProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const TRAINING_MODULES = [
  { title: 'Basic Life Support (BLS)', duration: '2 hours', progress: 100, status: 'completed', certificate: true },
  { title: 'Dementia Care Basics', duration: '1.5 hours', progress: 75, status: 'in-progress', certificate: false },
  { title: 'Medication Safety', duration: '1 hour', progress: 0, status: 'not-started', certificate: false },
  { title: 'Patient Communication', duration: '45 mins', progress: 0, status: 'not-started', certificate: false },
  { title: 'Emergency Response', duration: '2 hours', progress: 0, status: 'not-started', certificate: false }
];

export function Training({ onNavigate, onBack }: TrainingProps) {
  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      <div className="finance-card p-6 mb-4">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-4 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 style={{ color: '#535353' }}>Training & Certification</h1>
        <p style={{ color: '#848484' }}>Enhance your caregiving skills</p>
      </div>

      {/* Progress Overview */}
      <div className="px-6 mb-4">
        <div className="finance-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm mb-1" style={{ color: '#848484' }}>Overall Progress</p>
              <p className="text-2xl" style={{ color: '#FEB4C5' }}>35%</p>
            </div>
            <div className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)' }}>
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
          </div>
          <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'rgba(132, 132, 132, 0.1)' }}>
            <div className="h-2 rounded-full transition-all" style={{ width: '35%', background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)' }} />
          </div>
          <div className="grid grid-cols-3 gap-3 mt-4">
            <div className="text-center">
              <p className="text-xl" style={{ color: '#7CE577' }}>1</p>
              <p className="text-xs" style={{ color: '#848484' }}>Completed</p>
            </div>
            <div className="text-center">
              <p className="text-xl" style={{ color: '#FEB4C5' }}>1</p>
              <p className="text-xs" style={{ color: '#848484' }}>In Progress</p>
            </div>
            <div className="text-center">
              <p className="text-xl" style={{ color: '#848484' }}>3</p>
              <p className="text-xs" style={{ color: '#848484' }}>Not Started</p>
            </div>
          </div>
        </div>
      </div>

      {/* Training Modules */}
      <div className="px-6">
        <h2 className="mb-3" style={{ color: '#535353' }}>Available Courses</h2>
        <div className="space-y-3">
          {TRAINING_MODULES.map((module, idx) => (
            <div key={idx} className="finance-card p-5"
              style={{
                background: module.status === 'completed' ? 'rgba(124, 229, 119, 0.05)' :
                           module.status === 'in-progress' ? 'rgba(254, 180, 197, 0.05)' : 'white'
              }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 style={{ color: '#535353' }}>{module.title}</h3>
                    {module.certificate && (
                      <Award className="w-5 h-5" style={{ color: '#FFD54F' }} />
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm" style={{ color: '#848484' }}>
                    <Clock className="w-4 h-4" />
                    <span>{module.duration}</span>
                  </div>
                </div>
                {module.status === 'completed' && (
                  <CheckCircle className="w-6 h-6" style={{ color: '#7CE577' }} />
                )}
              </div>

              {module.progress > 0 && module.progress < 100 && (
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs mb-1" style={{ color: '#848484' }}>
                    <span>Progress</span>
                    <span>{module.progress}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'rgba(132, 132, 132, 0.1)' }}>
                    <div className="h-2 rounded-full transition-all"
                      style={{ width: `${module.progress}%`, background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)' }} />
                  </div>
                </div>
              )}

              <Button className="w-full py-2"
                style={{
                  background: module.status === 'completed' ? 'rgba(124, 229, 119, 0.2)' :
                             module.status === 'in-progress' ? 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)' :
                             'rgba(132, 132, 132, 0.1)',
                  color: module.status === 'completed' ? '#7CE577' :
                         module.status === 'in-progress' ? 'white' : '#535353'
                }}>
                {module.status === 'completed' && (
                  <>
                    <Award className="w-4 h-4 mr-2" />
                    View Certificate
                  </>
                )}
                {module.status === 'in-progress' && (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Continue Learning
                  </>
                )}
                {module.status === 'not-started' && 'Start Course'}
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Benefits */}
      <div className="px-6 mt-6">
        <div className="finance-card p-5" style={{ background: 'rgba(254, 180, 197, 0.1)' }}>
          <p className="text-sm mb-2" style={{ color: '#535353' }}><strong>💡 Training Benefits:</strong></p>
          <ul className="text-xs space-y-1" style={{ color: '#848484' }}>
            <li>✓ Improve your skills and knowledge</li>
            <li>✓ Earn certificates for your profile</li>
            <li>✓ Get priority for specialized jobs</li>
            <li>✓ Increase your hourly rate potential</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
