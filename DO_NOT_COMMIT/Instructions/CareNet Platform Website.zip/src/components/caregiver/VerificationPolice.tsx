import { VerificationPoliceClearance } from './VerificationPoliceClearance';

// Alternative/duplicate page for police verification
export function VerificationPolice(props: any) {
  return <VerificationPoliceClearance {...props} />;
}
