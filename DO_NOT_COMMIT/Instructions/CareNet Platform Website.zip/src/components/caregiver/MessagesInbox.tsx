import { ArrowLeft, Search, MessageCircle, Clock, CheckCheck } from 'lucide-react';
import { useState } from 'react';

interface Message {
  id: string;
  name: string;
  role: 'guardian' | 'agency' | 'patient';
  message: string;
  time: string;
  unread: boolean;
  avatar?: string;
}

interface MessagesInboxProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

export function MessagesInbox({ onNavigate, onBack }: MessagesInboxProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'guardian' | 'agency' | 'patient'>('all');

  const messages: Message[] = [
    {
      id: '1',
      name: 'Mr. Karim',
      role: 'guardian',
      message: 'Thank you for the excellent care today. My mother is very happy.',
      time: '2 min ago',
      unread: true
    },
    {
      id: '2',
      name: 'LifeCare Agency',
      role: 'agency',
      message: 'New job assignment available for tomorrow 9 AM - 5 PM',
      time: '15 min ago',
      unread: true
    },
    {
      id: '3',
      name: 'Mrs. Begum',
      role: 'patient',
      message: 'Please bring my reading glasses when you come tomorrow',
      time: '1 hour ago',
      unread: false
    },
    {
      id: '4',
      name: 'Ms. Rahman',
      role: 'guardian',
      message: 'Could you arrive 15 minutes early tomorrow? We have a doctor appointment.',
      time: '3 hours ago',
      unread: false
    },
    {
      id: '5',
      name: 'CareNet Support',
      role: 'agency',
      message: 'Your monthly subscription payment is due in 3 days',
      time: 'Yesterday',
      unread: false
    },
    {
      id: '6',
      name: 'Mr. Hossain',
      role: 'patient',
      message: 'I need help with physiotherapy exercises today',
      time: '2 days ago',
      unread: false
    }
  ];

  const filteredMessages = messages.filter(msg => {
    const matchesSearch = msg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         msg.message.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'all' || msg.role === activeFilter;
    return matchesSearch && matchesFilter;
  });

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'guardian':
        return '#5B9FFF';
      case 'agency':
        return '#FFB547';
      case 'patient':
        return '#FF6B9D';
      default:
        return '#848484';
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'guardian':
        return 'Guardian';
      case 'agency':
        return 'Agency';
      case 'patient':
        return 'Patient';
      default:
        return '';
    }
  };

  const unreadCount = messages.filter(m => m.unread).length;

  return (
    <div className="min-h-screen p-6 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => onBack ? onBack() : onNavigate?.('toc')}
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)' }}
        >
          <ArrowLeft className="w-5 h-5" style={{ color: '#535353' }} />
        </button>
        <div className="text-center">
          <h1 className="text-2xl" style={{ color: '#535353' }}>Messages</h1>
          <p className="text-sm" style={{ color: '#848484' }}>
            {unreadCount} unread
          </p>
        </div>
        <div className="w-10" />
      </div>

      {/* Search Bar */}
      <div className="mb-4">
        <div 
          className="flex items-center gap-3 px-4 py-3 rounded-2xl"
          style={{
            background: 'rgba(255, 255, 255, 0.6)',
            backdropFilter: 'blur(10px)',
            WebkitBackdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.3)'
          }}
        >
          <Search className="w-5 h-5" style={{ color: '#848484' }} />
          <input
            type="text"
            placeholder="Search messages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: '#535353' }}
          />
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {(['all', 'guardian', 'agency', 'patient'] as const).map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className="px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all"
            style={{
              background: activeFilter === filter 
                ? 'linear-gradient(135deg, #FF6B9D 0%, #FFA06B 100%)'
                : 'rgba(255, 255, 255, 0.6)',
              color: activeFilter === filter ? '#FFFFFF' : '#535353',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
          >
            {filter === 'all' ? 'All' : filter.charAt(0).toUpperCase() + filter.slice(1)}
          </button>
        ))}
      </div>

      {/* Messages List */}
      <div className="space-y-3">
        {filteredMessages.length === 0 ? (
          <div className="text-center py-12">
            <MessageCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#D3D3D3' }} />
            <p style={{ color: '#848484' }}>No messages found</p>
          </div>
        ) : (
          filteredMessages.map((message) => (
            <button
              key={message.id}
              onClick={() => onNavigate?.('/chat-screen')}
              className="w-full finance-card p-4 text-left hover:scale-[1.02] transition-all"
            >
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${getRoleColor(message.role)}20 0%, ${getRoleColor(message.role)}40 100%)`
                  }}
                >
                  <span className="text-lg">{message.name.charAt(0)}</span>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium" style={{ color: '#535353' }}>
                        {message.name}
                      </span>
                      {message.unread && (
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{ background: '#FF6B9D' }}
                        />
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" style={{ color: '#A0A0A0' }} />
                      <span className="text-xs whitespace-nowrap" style={{ color: '#A0A0A0' }}>
                        {message.time}
                      </span>
                    </div>
                  </div>

                  {/* Role Badge */}
                  <div className="mb-2">
                    <span
                      className="text-xs px-2 py-1 rounded-full"
                      style={{
                        background: `${getRoleColor(message.role)}20`,
                        color: getRoleColor(message.role)
                      }}
                    >
                      {getRoleBadge(message.role)}
                    </span>
                  </div>

                  {/* Message Preview */}
                  <p
                    className="text-sm truncate"
                    style={{ 
                      color: message.unread ? '#535353' : '#848484',
                      fontWeight: message.unread ? 500 : 400
                    }}
                  >
                    {message.message}
                  </p>
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}

export default MessagesInbox;
