import { Camera, RotateCcw, Check, X } from 'lucide-react';
import { useState } from 'react';

interface CheckInPhotoProps {
  onCapture: (hasPhoto: boolean) => void;
  onBack: () => void;
  patientName?: string;
}

export function CheckInPhoto({ 
  onCapture, 
  onBack,
  patientName = 'Mrs. Begum' 
}: CheckInPhotoProps) {
  const [photoTaken, setPhotoTaken] = useState(false);
  const [cameraActive, setCameraActive] = useState(true);

  const handleCapture = () => {
    setPhotoTaken(true);
    setCameraActive(false);
  };

  const handleRetake = () => {
    setPhotoTaken(false);
    setCameraActive(true);
  };

  const handleConfirm = () => {
    onCapture(photoTaken);
  };

  const handleSkip = () => {
    onCapture(false);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 pb-4">
        <button
          onClick={onBack}
          className="mb-4"
          style={{ color: '#535353' }}
        >
          <X className="w-6 h-6" />
        </button>
        <h1 className="text-2xl mb-2" style={{ color: '#535353' }}>
          Arrival Confirmation
        </h1>
        <p style={{ color: '#848484' }}>
          Take a photo to confirm arrival at {patientName}'s location
        </p>
      </div>

      {/* Camera Viewfinder / Photo Preview */}
      <div className="flex-1 p-6 flex items-center justify-center">
        <div 
          className="relative w-full max-w-md aspect-[3/4] rounded-3xl overflow-hidden"
          style={{
            background: photoTaken 
              ? 'linear-gradient(135deg, rgba(91, 159, 255, 0.2) 0%, rgba(255, 107, 157, 0.2) 100%)'
              : 'linear-gradient(135deg, rgba(0, 0, 0, 0.8) 0%, rgba(0, 0, 0, 0.6) 100%)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)'
          }}
        >
          {/* Camera Grid Overlay (when active) */}
          {cameraActive && !photoTaken && (
            <>
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                {[...Array(9)].map((_, i) => (
                  <div 
                    key={i}
                    className="border border-white/20"
                  />
                ))}
              </div>
              
              {/* Crosshair */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-32 h-32 border-2 border-white/50 rounded-full" />
              </div>

              {/* Camera Animation */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Camera className="w-16 h-16 text-white/50 mx-auto mb-4 animate-pulse" />
                  <p className="text-white/70 text-sm">Position camera to capture arrival</p>
                </div>
              </div>
            </>
          )}

          {/* Photo Preview (when taken) */}
          {photoTaken && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div
                  className="w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, #7CE577 0%, #6BD468 100%)'
                  }}
                >
                  <Check className="w-12 h-12 text-white" />
                </div>
                <p className="text-xl mb-2" style={{ color: '#535353' }}>Photo Captured!</p>
                <p className="text-sm" style={{ color: '#848484' }}>Review and confirm</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="p-6 pt-4 space-y-4">
        {!photoTaken ? (
          <>
            {/* Capture Button */}
            <button
              onClick={handleCapture}
              className="w-full py-4 rounded-2xl text-white font-medium transition-all hover:scale-105 active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #5B9FFF 0%, #4A8FEF 100%)',
                boxShadow: '0 4px 16px rgba(91, 159, 255, 0.4)'
              }}
            >
              <div className="flex items-center justify-center gap-3">
                <Camera className="w-6 h-6" />
                <span className="text-lg">Capture Photo</span>
              </div>
            </button>

            {/* Skip Button */}
            <button
              onClick={handleSkip}
              className="w-full py-3 rounded-2xl font-medium transition-all"
              style={{
                background: 'rgba(255, 255, 255, 0.6)',
                color: '#848484'
              }}
            >
              Skip Photo
            </button>
          </>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {/* Retake Button */}
            <button
              onClick={handleRetake}
              className="py-3 rounded-xl font-medium transition-all hover:scale-105 flex items-center justify-center gap-2"
              style={{
                background: 'rgba(255, 255, 255, 0.6)',
                color: '#535353'
              }}
            >
              <RotateCcw className="w-5 h-5" />
              Retake
            </button>

            {/* Confirm Button */}
            <button
              onClick={handleConfirm}
              className="py-3 rounded-xl text-white font-medium transition-all hover:scale-105 flex items-center justify-center gap-2"
              style={{
                background: 'linear-gradient(135deg, #7CE577 0%, #6BD468 100%)'
              }}
            >
              <Check className="w-5 h-5" />
              Confirm
            </button>
          </div>
        )}

        {/* Info Text */}
        <p className="text-xs text-center" style={{ color: '#A0A0A0' }}>
          {photoTaken 
            ? 'This photo will be timestamped and logged for attendance verification'
            : 'Photo helps verify arrival time and location'
          }
        </p>
      </div>
    </div>
  );
}

export default CheckInPhoto;
