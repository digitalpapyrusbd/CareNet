import { Lock, CheckCircle2, XCircle, CreditCard, Clock, AlertCircle, ArrowLeft } from 'lucide-react';

interface AccountLockedProps {
  outstandingAmount?: number;
  daysPastDue?: number;
  onNavigate?: (page: string) => void;
}

export function AccountLocked({ 
  outstandingAmount = 5000, 
  daysPastDue = 3,
  onNavigate 
}: AccountLockedProps) {
  const restrictedFeatures = [
    'Cannot accept new job assignments',
    'Cannot update availability calendar',
    'Cannot generate new invoices',
    'Cannot access subscription features',
    'Profile hidden from agency searches'
  ];

  const allowedFeatures = [
    'Complete existing assigned jobs',
    'Check-in/Check-out for active jobs',
    'Submit care logs and reports',
    'Communicate with guardians and agencies',
    'View earnings history',
    'Make payment to unlock account'
  ];

  return (
    <div className="min-h-screen p-6 pb-24">
      {/* Back Button */}
      <button
        onClick={() => onNavigate?.('toc')}
        className="w-10 h-10 rounded-full flex items-center justify-center mb-6"
        style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)' }}
      >
        <ArrowLeft className="w-5 h-5" style={{ color: '#535353' }} />
      </button>

      {/* Warning Header */}
      <div
        className="rounded-3xl p-6 mb-6 text-center"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 107, 107, 0.15) 0%, rgba(255, 179, 71, 0.15) 100%)',
          border: '2px solid rgba(255, 107, 107, 0.3)'
        }}
      >
        <div
          className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center"
          style={{
            background: 'linear-gradient(135deg, #FF6B6B 0%, #FFB347 100%)'
          }}
        >
          <Lock className="w-10 h-10 text-white" />
        </div>
        
        <h1 className="text-2xl mb-2" style={{ color: '#535353' }}>
          Account Locked
        </h1>
        <p style={{ color: '#848484' }}>
          Your account has been locked due to payment overdue
        </p>
      </div>

      {/* Outstanding Balance Card */}
      <div className="finance-card p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <AlertCircle className="w-5 h-5" style={{ color: '#FF6B6B' }} />
          <h2 style={{ color: '#535353' }}>Outstanding Balance</h2>
        </div>

        <div className="text-center py-6">
          <div className="text-4xl mb-2" style={{ color: '#FF6B6B' }}>
            ৳{outstandingAmount.toLocaleString()}
          </div>
          <div className="flex items-center justify-center gap-2" style={{ color: '#848484' }}>
            <Clock className="w-4 h-4" />
            <span className="text-sm">{daysPastDue} days overdue</span>
          </div>
        </div>

        <button
          onClick={() => onNavigate?.('/caregiver/subscription-plans')}
          className="w-full py-4 rounded-2xl text-white font-medium transition-all hover:scale-105"
          style={{
            background: 'linear-gradient(135deg, #FF6B9D 0%, #FFA06B 100%)'
          }}
        >
          <div className="flex items-center justify-center gap-2">
            <CreditCard className="w-5 h-5" />
            <span>Pay Outstanding Balance</span>
          </div>
        </button>
      </div>

      {/* Restricted Features */}
      <div className="finance-card p-6 mb-4">
        <div className="flex items-center gap-2 mb-4">
          <XCircle className="w-5 h-5" style={{ color: '#FF6B6B' }} />
          <h2 style={{ color: '#535353' }}>Restricted Features</h2>
        </div>
        <div className="space-y-3">
          {restrictedFeatures.map((feature, index) => (
            <div key={index} className="flex items-start gap-3">
              <div
                className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ background: 'rgba(255, 107, 107, 0.15)' }}
              >
                <XCircle className="w-4 h-4" style={{ color: '#FF6B6B' }} />
              </div>
              <p className="text-sm" style={{ color: '#848484' }}>{feature}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Allowed Features */}
      <div className="finance-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <CheckCircle2 className="w-5 h-5" style={{ color: '#7CE577' }} />
          <h2 style={{ color: '#535353' }}>You Can Still</h2>
        </div>
        <div className="space-y-3">
          {allowedFeatures.map((feature, index) => (
            <div key={index} className="flex items-start gap-3">
              <div
                className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ background: 'rgba(124, 229, 119, 0.15)' }}
              >
                <CheckCircle2 className="w-4 h-4" style={{ color: '#7CE577' }} />
              </div>
              <p className="text-sm" style={{ color: '#535353' }}>{feature}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Help Text */}
      <div className="mt-6 text-center">
        <p className="text-sm mb-2" style={{ color: '#848484' }}>
          Need help with payment arrangements?
        </p>
        <button
          onClick={() => onNavigate?.('/chat-screen')}
          className="text-sm underline"
          style={{ color: '#5B9FFF' }}
        >
          Contact Support
        </button>
      </div>
    </div>
  );
}

export default AccountLocked;