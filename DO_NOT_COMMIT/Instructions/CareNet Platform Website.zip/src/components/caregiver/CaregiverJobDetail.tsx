import { ArrowLeft, User, Calendar, Clock, MapPin, AlertCircle, Phone, Navigation, Pill, FileText } from 'lucide-react';
import { Button } from '../ui/button';

interface CaregiverJobDetailProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const PATIENT = {
  name: 'Mrs. Fatima Rahman',
  age: 72,
  gender: 'Female',
  photo: null,
  conditions: ['Type 2 Diabetes', 'Hypertension', 'Arthritis'],
  allergies: ['Penicillin', 'Aspirin'],
  mobility: 'Wheelchair bound',
  specialInstructions: 'Patient requires assistance with all daily activities. Monitor blood sugar before meals. Gentle exercises twice daily.',
  address: 'House 45, Road 12, Dhanmondi, Dhaka 1209',
  guardian: { name: 'Sadia Rahman', phone: '+880 1712-345678' }
};

const MEDICATIONS = [
  { name: 'Metformin', dosage: '500mg', time: '8:00 AM, 8:00 PM', withFood: true },
  { name: 'Amlodipine', dosage: '5mg', time: '9:00 AM', withFood: false },
  { name: 'Insulin', dosage: '10 units', time: 'Before meals', withFood: false }
];

const SCHEDULE = [
  { time: '9:00 AM', activity: 'Check-in & Vitals', done: true },
  { time: '9:30 AM', activity: 'Breakfast & Medications', done: true },
  { time: '11:00 AM', activity: 'Light Exercise', done: false },
  { time: '1:00 PM', activity: 'Lunch & Medications', done: false },
  { time: '3:00 PM', activity: 'Afternoon Rest', done: false },
  { time: '5:00 PM', activity: 'Check-out & Report', done: false }
];

export function CaregiverJobDetail({ onNavigate, onBack }: CaregiverJobDetailProps) {
  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      {/* Header */}
      <div className="finance-card p-6 mb-4">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-4 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 style={{ color: '#535353' }}>Job Details</h1>
      </div>

      {/* Patient Info Card */}
      <div className="px-6 mb-4">
        <div className="finance-card p-5">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: 'rgba(254, 180, 197, 0.2)' }}>
              <User className="w-8 h-8" style={{ color: '#FEB4C5' }} />
            </div>
            <div className="flex-1">
              <h2 style={{ color: '#535353' }}>{PATIENT.name}</h2>
              <p className="text-sm" style={{ color: '#848484' }}>{PATIENT.age} years • {PATIENT.gender}</p>
              <div className="flex items-center gap-2 mt-2">
                <MapPin className="w-4 h-4" style={{ color: '#848484' }} />
                <p className="text-sm" style={{ color: '#535353' }}>{PATIENT.address}</p>
              </div>
            </div>
          </div>

          {/* Conditions */}
          <div className="mb-4">
            <p className="text-sm mb-2" style={{ color: '#535353' }}><strong>Medical Conditions:</strong></p>
            <div className="flex flex-wrap gap-2">
              {PATIENT.conditions.map((condition) => (
                <span key={condition} className="px-3 py-1 rounded-full text-xs" style={{ background: 'rgba(254, 180, 197, 0.2)', color: '#FEB4C5' }}>
                  {condition}
                </span>
              ))}
            </div>
          </div>

          {/* Allergies - RED HIGHLIGHT */}
          <div className="mb-4 p-3 rounded-lg" style={{ background: 'rgba(255, 107, 107, 0.1)' }}>
            <div className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" style={{ color: '#FF6B6B' }} />
              <div>
                <p className="text-sm mb-1" style={{ color: '#FF6B6B' }}><strong>⚠️ ALLERGIES:</strong></p>
                <p className="text-sm" style={{ color: '#535353' }}>{PATIENT.allergies.join(', ')}</p>
              </div>
            </div>
          </div>

          {/* Mobility */}
          <div className="mb-4">
            <p className="text-sm mb-1" style={{ color: '#535353' }}><strong>Mobility:</strong></p>
            <p className="text-sm" style={{ color: '#848484' }}>{PATIENT.mobility}</p>
          </div>

          {/* Special Instructions */}
          <div>
            <p className="text-sm mb-1" style={{ color: '#535353' }}><strong>Special Instructions:</strong></p>
            <p className="text-sm" style={{ color: '#848484' }}>{PATIENT.specialInstructions}</p>
          </div>
        </div>
      </div>

      {/* Medication Schedule */}
      <div className="px-6 mb-4">
        <h2 className="mb-3" style={{ color: '#535353' }}>Medication Schedule</h2>
        <div className="space-y-3">
          {MEDICATIONS.map((med, idx) => (
            <div key={idx} className="finance-card p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ background: 'rgba(155, 156, 248, 0.2)' }}>
                  <Pill className="w-5 h-5" style={{ color: '#9B9CF8' }} />
                </div>
                <div className="flex-1">
                  <h3 style={{ color: '#535353' }}>{med.name}</h3>
                  <p className="text-sm" style={{ color: '#848484' }}>{med.dosage} • {med.time}</p>
                  {med.withFood && (
                    <p className="text-xs mt-1" style={{ color: '#FEB4C5' }}>⚠️ Take with food</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Today's Schedule */}
      <div className="px-6 mb-4">
        <h2 className="mb-3" style={{ color: '#535353' }}>Today's Schedule</h2>
        <div className="finance-card p-5">
          <div className="space-y-4">
            {SCHEDULE.map((item, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <div className="text-sm shrink-0" style={{ color: item.done ? '#7CE577' : '#848484', width: '70px' }}>
                  {item.time}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center ${item.done ? '' : 'border-2'}`}
                      style={{ background: item.done ? '#7CE577' : 'transparent', borderColor: item.done ? 'transparent' : '#848484' }}>
                      {item.done && <span className="text-white text-xs">✓</span>}
                    </div>
                    <p className="text-sm" style={{ color: item.done ? '#7CE577' : '#535353', textDecoration: item.done ? 'line-through' : 'none' }}>
                      {item.activity}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Guardian Contact */}
      <div className="px-6 mb-4">
        <div className="finance-card p-5">
          <p className="text-sm mb-2" style={{ color: '#535353' }}><strong>Guardian:</strong></p>
          <p style={{ color: '#535353' }}>{PATIENT.guardian.name}</p>
          <p className="text-sm" style={{ color: '#848484' }}>{PATIENT.guardian.phone}</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-6 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Button onClick={() => onNavigate?.('caregiver-care-logs')} className="py-4"
            style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)', color: 'white' }}>
            <FileText className="w-5 h-5 mr-2" />
            Care Logs
          </Button>
          <Button variant="outline" className="py-4"
            style={{ color: '#535353', borderColor: 'rgba(132, 132, 132, 0.2)' }}>
            <Navigation className="w-5 h-5 mr-2" />
            Navigate
          </Button>
        </div>
        <Button className="w-full py-4" style={{ background: '#FF6B6B', color: 'white' }}>
          <Phone className="w-5 h-5 mr-2" />
          Emergency Call
        </Button>
      </div>
    </div>
  );
}
