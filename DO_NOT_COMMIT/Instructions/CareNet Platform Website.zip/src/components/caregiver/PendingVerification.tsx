import { Clock, CheckCircle, Circle, AlertCircle } from 'lucide-react';
import { Button } from '../ui/button';

interface PendingVerificationProps {
  onNavigate?: (page: string) => void;
}

const VERIFICATION_STEPS = [
  { name: 'Certificates Review', status: 'completed', time: '2-3 hours' },
  { name: 'Police Clearance', status: 'in-progress', time: '3-5 days' },
  { name: 'Interview Schedule', status: 'pending', time: '1-2 days' },
  { name: 'Psychological Assessment', status: 'pending', time: '1-2 days' },
  { name: 'Document Verification', status: 'pending', time: '1 day' },
  { name: 'Final Approval', status: 'pending', time: '24 hours' }
];

export function PendingVerification({ onNavigate }: PendingVerificationProps) {
  const currentStep = VERIFICATION_STEPS.findIndex(step => step.status === 'in-progress');

  return (
    <div className="min-h-screen flex flex-col p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <div
          className="inline-flex items-center justify-center w-24 h-24 rounded-full mb-4 animate-pulse"
          style={{
            background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)',
            boxShadow: '0px 4px 18px rgba(240, 161, 180, 0.4)'
          }}
        >
          <Clock className="w-12 h-12 text-white" />
        </div>
        <h1 className="mb-2" style={{ color: '#535353' }}>Verification in Progress</h1>
        <p style={{ color: '#848484' }}>
          Your application is being reviewed by our verification team
        </p>
      </div>

      {/* Overall Progress */}
      <div className="finance-card p-5 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span style={{ color: '#535353' }}>Overall Progress</span>
          <span style={{ color: '#FEB4C5' }}>
            {Math.round(((currentStep) / VERIFICATION_STEPS.length) * 100)}%
          </span>
        </div>
        <div className="w-full h-3 rounded-full" style={{ backgroundColor: 'rgba(132, 132, 132, 0.1)' }}>
          <div
            className="h-3 rounded-full transition-all duration-500"
            style={{
              width: `${((currentStep) / VERIFICATION_STEPS.length) * 100}%`,
              background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)'
            }}
          />
        </div>
        <p className="text-xs mt-2 text-center" style={{ color: '#848484' }}>
          Estimated completion: 7-14 business days
        </p>
      </div>

      {/* Verification Steps */}
      <div className="space-y-4 flex-1">
        {VERIFICATION_STEPS.map((step, index) => (
          <div
            key={index}
            className="finance-card p-4"
            style={{
              background: step.status === 'in-progress' 
                ? 'rgba(254, 180, 197, 0.1)' 
                : step.status === 'completed'
                ? 'rgba(168, 224, 99, 0.1)'
                : 'white'
            }}
          >
            <div className="flex items-start gap-4">
              <div className="shrink-0">
                {step.status === 'completed' ? (
                  <CheckCircle className="w-6 h-6" style={{ color: '#7CE577' }} />
                ) : step.status === 'in-progress' ? (
                  <div className="relative">
                    <Circle className="w-6 h-6 animate-pulse" style={{ color: '#FEB4C5' }} />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full" style={{ background: '#FEB4C5' }} />
                    </div>
                  </div>
                ) : (
                  <Circle className="w-6 h-6" style={{ color: '#848484' }} />
                )}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h3 style={{ color: '#535353' }}>Step {index + 1}: {step.name}</h3>
                  {step.status === 'in-progress' && (
                    <span className="px-2 py-1 rounded-full text-xs" style={{ background: '#FEB4C5', color: 'white' }}>
                      In Progress
                    </span>
                  )}
                  {step.status === 'completed' && (
                    <span className="px-2 py-1 rounded-full text-xs" style={{ background: '#7CE577', color: 'white' }}>
                      Completed
                    </span>
                  )}
                </div>
                <p className="text-sm" style={{ color: '#848484' }}>
                  {step.status === 'completed' 
                    ? 'Verified successfully' 
                    : step.status === 'in-progress'
                    ? 'Currently under review'
                    : `Est. time: ${step.time}`
                  }
                </p>
              </div>
            </div>

            {step.status === 'in-progress' && step.name === 'Police Clearance' && (
              <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(132, 132, 132, 0.1)' }}>
                <Button
                  onClick={() => onNavigate?.('caregiver-verification-police')}
                  className="w-full py-2"
                  style={{
                    background: 'rgba(254, 180, 197, 0.2)',
                    color: '#FEB4C5'
                  }}
                >
                  Upload Police Clearance
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Info Card */}
      <div className="finance-card p-4 mt-6" style={{ background: 'rgba(254, 180, 197, 0.1)' }}>
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" style={{ color: '#FEB4C5' }} />
          <div>
            <p className="text-sm mb-1" style={{ color: '#535353' }}>
              What happens next?
            </p>
            <ul className="text-xs space-y-1" style={{ color: '#848484' }}>
              <li>✓ You'll receive notifications for each step</li>
              <li>✓ We may contact you for additional information</li>
              <li>✓ Once approved, you can start accepting jobs</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Support Button */}
      <Button
        variant="outline"
        className="w-full py-4 mt-4"
        style={{ color: '#535353', borderColor: 'rgba(132, 132, 132, 0.2)' }}
      >
        Contact Support
      </Button>
    </div>
  );
}
