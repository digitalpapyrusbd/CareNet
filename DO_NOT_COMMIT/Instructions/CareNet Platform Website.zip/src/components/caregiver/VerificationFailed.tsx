import { XCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '../ui/button';

interface VerificationFailedProps {
  onNavigate?: (page: string) => void;
}

export function VerificationFailed({ onNavigate }: VerificationFailedProps) {
  const reasons = [
    'Police clearance document could not be verified',
    'Incomplete medical fitness certificate',
    'Discrepancies found in submitted NID information'
  ];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="text-center max-w-md">
        <div className="inline-flex items-center justify-center w-32 h-32 rounded-full mb-6"
          style={{ background: 'rgba(255, 107, 107, 0.1)' }}>
          <XCircle className="w-16 h-16" style={{ color: '#FF6B6B' }} />
        </div>

        <h1 className="mb-4" style={{ color: '#535353' }}>Verification Not Approved</h1>
        <p className="mb-8" style={{ color: '#848484' }}>
          Unfortunately, we couldn't complete your verification at this time.
        </p>

        <div className="finance-card p-5 mb-6" style={{ background: 'rgba(255, 107, 107, 0.1)' }}>
          <div className="flex items-start gap-3 mb-4">
            <AlertCircle className="w-6 h-6 shrink-0 mt-0.5" style={{ color: '#FF6B6B' }} />
            <div className="text-left">
              <p className="mb-2" style={{ color: '#535353' }}><strong>Reasons for Rejection:</strong></p>
              <ul className="text-sm space-y-2" style={{ color: '#848484' }}>
                {reasons.map((reason, idx) => (
                  <li key={idx}>• {reason}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="finance-card p-5 mb-8">
          <p className="text-sm mb-3" style={{ color: '#535353' }}>
            <strong>You Can Reapply:</strong>
          </p>
          <ul className="text-sm space-y-2 text-left" style={{ color: '#848484' }}>
            <li>✓ After 30 days from today</li>
            <li>✓ Address all rejection reasons</li>
            <li>✓ Submit corrected documents</li>
            <li>✓ Complete new assessments if required</li>
          </ul>
        </div>

        <Button onClick={() => onNavigate?.('landing')} className="w-full py-6 mb-3"
          style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FEB4C5 0%, #DB869A 100%)', color: 'white' }}>
          <RefreshCw className="w-5 h-5 mr-2" />
          Start New Application (After 30 Days)
        </Button>

        <Button onClick={() => onNavigate?.('landing')} variant="outline" className="w-full py-4"
          style={{ color: '#535353', borderColor: 'rgba(132, 132, 132, 0.2)' }}>
          Contact Support
        </Button>
      </div>
    </div>
  );
}
