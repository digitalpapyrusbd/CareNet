import { ArrowLeft, Calendar, Clock, MapPin, CheckCircle } from 'lucide-react';
import { Button } from '../ui/button';
import { useState } from 'react';

interface HistoryProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
}

const JOB_HISTORY = [
  { id: 1, patient: 'Mrs. Khaleda Akter', date: 'Dec 24, 2024', duration: '8 hours', location: 'Mirpur', rating: 5, earned: '৳4,800' },
  { id: 2, patient: 'Mr. Abdul Hamid', date: 'Dec 23, 2024', duration: '8 hours', location: 'Mohakhali', rating: 5, earned: '৳4,800' },
  { id: 3, patient: 'Mrs. Nasrin Begum', date: 'Dec 22, 2024', duration: '6 hours', location: 'Uttara', rating: 4, earned: '৳3,600' },
  { id: 4, patient: 'Mr. Karim Ahmed', date: 'Dec 21, 2024', duration: '8 hours', location: 'Gulshan', rating: 5, earned: '৳4,800' },
  { id: 5, patient: 'Mrs. Fatima Rahman', date: 'Dec 20, 2024', duration: '8 hours', location: 'Dhanmondi', rating: 5, earned: '৳4,800' }
];

export function History({ onNavigate, onBack }: HistoryProps) {
  const [filter, setFilter] = useState<'all' | 'month' | 'quarter'>('all');

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      <div className="finance-card p-6 mb-4">
        <Button variant="ghost" onClick={() => onBack?.()} className="mb-4 hover:bg-white/30" style={{ color: '#535353' }}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 style={{ color: '#535353' }}>Job History</h1>
        <p style={{ color: '#848484' }}>Your completed assignments</p>
      </div>

      {/* Filter */}
      <div className="px-6 mb-4">
        <div className="finance-card p-2 flex gap-2">
          {(['all', 'month', 'quarter'] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className={`flex-1 py-2 rounded-lg transition-all text-sm ${filter === f ? 'finance-card' : ''}`}
              style={{ color: filter === f ? '#FEB4C5' : '#848484', background: filter === f ? 'white' : 'transparent' }}>
              {f === 'all' ? 'All Time' : f === 'month' ? 'This Month' : 'Last 3 Months'}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="px-6 mb-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="finance-card p-4 text-center">
            <p className="text-2xl mb-1" style={{ color: '#FEB4C5' }}>38</p>
            <p className="text-xs" style={{ color: '#848484' }}>Total Jobs</p>
          </div>
          <div className="finance-card p-4 text-center">
            <p className="text-2xl mb-1" style={{ color: '#7CE577' }}>298h</p>
            <p className="text-xs" style={{ color: '#848484' }}>Hours</p>
          </div>
          <div className="finance-card p-4 text-center">
            <p className="text-2xl mb-1" style={{ color: '#FFD54F' }}>4.9★</p>
            <p className="text-xs" style={{ color: '#848484' }}>Avg Rating</p>
          </div>
        </div>
      </div>

      {/* Job List */}
      <div className="px-6 space-y-3">
        {JOB_HISTORY.map((job) => (
          <div key={job.id} className="finance-card p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 style={{ color: '#535353' }}>{job.patient}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Calendar className="w-4 h-4" style={{ color: '#848484' }} />
                  <span className="text-sm" style={{ color: '#848484' }}>{job.date}</span>
                </div>
              </div>
              <CheckCircle className="w-6 h-6" style={{ color: '#7CE577' }} />
            </div>

            <div className="flex items-center gap-4 mb-3 text-sm" style={{ color: '#848484' }}>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>{job.duration}</span>
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>{job.location}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t" style={{ borderColor: 'rgba(132, 132, 132, 0.1)' }}>
              <div className="flex items-center gap-1" style={{ color: '#FFD54F' }}>
                {'⭐'.repeat(job.rating)}
              </div>
              <p style={{ color: '#7CE577' }}>{job.earned}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
