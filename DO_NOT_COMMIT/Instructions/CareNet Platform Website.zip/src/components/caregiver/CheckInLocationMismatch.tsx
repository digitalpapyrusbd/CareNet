import { MapPin, AlertTriangle, Navigation } from 'lucide-react';
import { useState } from 'react';

interface CheckInLocationMismatchProps {
  expectedLocation: string;
  currentLocation: string;
  distance: number; // in meters
  onProceed: (note: string) => void;
  onCancel: () => void;
}

export function CheckInLocationMismatch({
  expectedLocation = 'House 12, Road 5, Dhanmondi, Dhaka',
  currentLocation = 'House 8, Road 5, Dhanmondi, Dhaka',
  distance = 85,
  onProceed,
  onCancel
}: CheckInLocationMismatchProps) {
  const [note, setNote] = useState('');

  const handleProceed = () => {
    if (note.trim()) {
      onProceed(note.trim());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
      />

      {/* Modal */}
      <div 
        className="relative w-full max-w-md rounded-3xl p-6"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.85) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)'
        }}
      >
        {/* Warning Icon */}
        <div
          className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center"
          style={{
            background: 'linear-gradient(135deg, #FFB547 0%, #FF9F47 100%)'
          }}
        >
          <AlertTriangle className="w-10 h-10 text-white" />
        </div>

        {/* Title */}
        <h2 className="text-2xl text-center mb-2" style={{ color: '#535353' }}>
          Location Mismatch
        </h2>
        <p className="text-center mb-6" style={{ color: '#848484' }}>
          You appear to be {distance}m away from the patient's location
        </p>

        {/* Location Details */}
        <div className="space-y-3 mb-6">
          {/* Expected Location */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: 'rgba(124, 229, 119, 0.1)',
              border: '1px solid rgba(124, 229, 119, 0.3)'
            }}
          >
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#7CE577' }} />
              <div className="flex-1">
                <p className="text-xs mb-1" style={{ color: '#7CE577' }}>
                  Expected Location
                </p>
                <p className="text-sm" style={{ color: '#535353' }}>
                  {expectedLocation}
                </p>
              </div>
            </div>
          </div>

          {/* Current Location */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: 'rgba(255, 181, 71, 0.1)',
              border: '1px solid rgba(255, 181, 71, 0.3)'
            }}
          >
            <div className="flex items-start gap-3">
              <Navigation className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#FFB547' }} />
              <div className="flex-1">
                <p className="text-xs mb-1" style={{ color: '#FFB547' }}>
                  Your Current Location
                </p>
                <p className="text-sm" style={{ color: '#535353' }}>
                  {currentLocation}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Distance Warning */}
        <div
          className="rounded-2xl p-4 mb-6"
          style={{
            background: 'rgba(255, 107, 107, 0.1)',
            border: '1px solid rgba(255, 107, 107, 0.3)'
          }}
        >
          <p className="text-sm text-center" style={{ color: '#FF6B6B' }}>
            Distance: <span className="font-medium">{distance} meters</span> from patient location
          </p>
        </div>

        {/* Explanation Note (Required) */}
        <div className="mb-6">
          <label className="block mb-3 font-medium" style={{ color: '#535353' }}>
            Explain Location Difference (Required)
          </label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="E.g., Patient moved to a different house temporarily, using nearby parking area, etc."
            rows={4}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353',
              resize: 'none'
            }}
          />
          <p className="text-xs mt-2" style={{ color: '#A0A0A0' }}>
            This note will be logged and visible to Guardian and Agency
          </p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onCancel}
            className="py-3 rounded-xl font-medium transition-all hover:scale-105"
            style={{
              background: 'rgba(0, 0, 0, 0.05)',
              color: '#535353'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleProceed}
            disabled={!note.trim()}
            className="py-3 rounded-xl text-white font-medium transition-all hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
            style={{
              background: note.trim()
                ? 'linear-gradient(135deg, #FFB547 0%, #FF9F47 100%)'
                : 'rgba(0, 0, 0, 0.2)'
            }}
          >
            Proceed with Override
          </button>
        </div>

        {/* Warning Text */}
        <p className="text-xs text-center mt-4" style={{ color: '#848484' }}>
          ⚠️ Location overrides are monitored for quality assurance
        </p>
      </div>
    </div>
  );
}

export default CheckInLocationMismatch;
