import { X, Activity, Heart, Thermometer, Droplet, Wind, AlertTriangle } from 'lucide-react';
import { useState } from 'react';

interface VitalReading {
  systolic?: string;
  diastolic?: string;
  heartRate?: string;
  temperature?: string;
  bloodGlucose?: string;
  oxygenLevel?: string;
}

interface CareLogVitalsProps {
  onClose: () => void;
  onSave: (vitals: VitalReading) => void;
  patientName?: string;
}

export function CareLogVitals({ 
  onClose, 
  onSave, 
  patientName = 'Mrs. Begum' 
}: CareLogVitalsProps) {
  const [vitals, setVitals] = useState<VitalReading>({
    systolic: '',
    diastolic: '',
    heartRate: '',
    temperature: '',
    bloodGlucose: '',
    oxygenLevel: ''
  });

  const [warnings, setWarnings] = useState<string[]>([]);

  const checkAbnormal = (field: keyof VitalReading, value: string) => {
    const newWarnings: string[] = [];
    const numValue = parseFloat(value);

    if (field === 'systolic' && numValue && (numValue < 90 || numValue > 140)) {
      newWarnings.push('Blood pressure may be abnormal');
    }
    if (field === 'diastolic' && numValue && (numValue < 60 || numValue > 90)) {
      newWarnings.push('Blood pressure may be abnormal');
    }
    if (field === 'heartRate' && numValue && (numValue < 60 || numValue > 100)) {
      newWarnings.push('Heart rate is outside normal range');
    }
    if (field === 'temperature' && numValue && (numValue < 36.1 || numValue > 37.2)) {
      newWarnings.push('Temperature may be abnormal');
    }
    if (field === 'bloodGlucose' && numValue && (numValue < 70 || numValue > 140)) {
      newWarnings.push('Blood glucose level needs attention');
    }
    if (field === 'oxygenLevel' && numValue && numValue < 95) {
      newWarnings.push('Oxygen saturation is low');
    }

    setWarnings(newWarnings);
  };

  const handleChange = (field: keyof VitalReading, value: string) => {
    setVitals(prev => ({ ...prev, [field]: value }));
    checkAbnormal(field, value);
  };

  const handleSave = () => {
    onSave(vitals);
    onClose();
  };

  const hasAnyVital = Object.values(vitals).some(v => v !== '');

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Bottom Sheet */}
      <div 
        className="relative w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 max-h-[90vh] overflow-y-auto"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.85) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          boxShadow: '0 -4px 24px rgba(0, 0, 0, 0.1), 0 8px 32px rgba(0, 0, 0, 0.1)'
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl mb-1" style={{ color: '#535353' }}>Record Vitals</h2>
            <p className="text-sm" style={{ color: '#848484' }}>{patientName}</p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0, 0, 0, 0.05)' }}
          >
            <X className="w-5 h-5" style={{ color: '#535353' }} />
          </button>
        </div>

        {/* Warnings */}
        {warnings.length > 0 && (
          <div
            className="rounded-2xl p-4 mb-6"
            style={{
              background: 'rgba(255, 107, 107, 0.1)',
              border: '1px solid rgba(255, 107, 107, 0.3)'
            }}
          >
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" style={{ color: '#FF6B6B' }} />
              <div className="flex-1">
                <p className="font-medium mb-1" style={{ color: '#FF6B6B' }}>
                  Abnormal Reading Detected
                </p>
                {warnings.map((warning, index) => (
                  <p key={index} className="text-sm" style={{ color: '#848484' }}>
                    • {warning}
                  </p>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Blood Pressure */}
        <div className="mb-6">
          <label className="flex items-center gap-2 mb-3" style={{ color: '#535353' }}>
            <Activity className="w-5 h-5" style={{ color: '#FF6B9D' }} />
            <span>Blood Pressure (mmHg)</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <input
                type="number"
                placeholder="Systolic"
                value={vitals.systolic}
                onChange={(e) => handleChange('systolic', e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-center outline-none"
                style={{
                  background: 'rgba(255, 255, 255, 0.8)',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  color: '#535353'
                }}
              />
              <p className="text-xs text-center mt-1" style={{ color: '#A0A0A0' }}>Systolic</p>
            </div>
            <div>
              <input
                type="number"
                placeholder="Diastolic"
                value={vitals.diastolic}
                onChange={(e) => handleChange('diastolic', e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-center outline-none"
                style={{
                  background: 'rgba(255, 255, 255, 0.8)',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  color: '#535353'
                }}
              />
              <p className="text-xs text-center mt-1" style={{ color: '#A0A0A0' }}>Diastolic</p>
            </div>
          </div>
        </div>

        {/* Heart Rate */}
        <div className="mb-6">
          <label className="flex items-center gap-2 mb-3" style={{ color: '#535353' }}>
            <Heart className="w-5 h-5" style={{ color: '#FF6B9D' }} />
            <span>Heart Rate (bpm)</span>
          </label>
          <input
            type="number"
            placeholder="e.g., 72"
            value={vitals.heartRate}
            onChange={(e) => handleChange('heartRate', e.target.value)}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353'
            }}
          />
        </div>

        {/* Temperature */}
        <div className="mb-6">
          <label className="flex items-center gap-2 mb-3" style={{ color: '#535353' }}>
            <Thermometer className="w-5 h-5" style={{ color: '#FFB547' }} />
            <span>Temperature (°C)</span>
          </label>
          <input
            type="number"
            step="0.1"
            placeholder="e.g., 36.8"
            value={vitals.temperature}
            onChange={(e) => handleChange('temperature', e.target.value)}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353'
            }}
          />
        </div>

        {/* Blood Glucose */}
        <div className="mb-6">
          <label className="flex items-center gap-2 mb-3" style={{ color: '#535353' }}>
            <Droplet className="w-5 h-5" style={{ color: '#5B9FFF' }} />
            <span>Blood Glucose (mg/dL)</span>
          </label>
          <input
            type="number"
            placeholder="e.g., 110"
            value={vitals.bloodGlucose}
            onChange={(e) => handleChange('bloodGlucose', e.target.value)}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353'
            }}
          />
        </div>

        {/* Oxygen Level */}
        <div className="mb-6">
          <label className="flex items-center gap-2 mb-3" style={{ color: '#535353' }}>
            <Wind className="w-5 h-5" style={{ color: '#7CE577' }} />
            <span>Oxygen Saturation (%)</span>
          </label>
          <input
            type="number"
            placeholder="e.g., 98"
            value={vitals.oxygenLevel}
            onChange={(e) => handleChange('oxygenLevel', e.target.value)}
            className="w-full px-4 py-3 rounded-xl outline-none"
            style={{
              background: 'rgba(255, 255, 255, 0.8)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#535353'
            }}
          />
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onClose}
            className="py-3 rounded-xl font-medium transition-all"
            style={{
              background: 'rgba(0, 0, 0, 0.05)',
              color: '#535353'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!hasAnyVital}
            className="py-3 rounded-xl text-white font-medium transition-all hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
            style={{
              background: hasAnyVital 
                ? 'linear-gradient(135deg, #5B9FFF 0%, #4A8FEF 100%)'
                : 'rgba(0, 0, 0, 0.2)'
            }}
          >
            Save Vitals
          </button>
        </div>

        {/* Info Note */}
        <p className="text-xs text-center mt-4" style={{ color: '#A0A0A0' }}>
          All fields are optional. Record what's available.
        </p>
      </div>
    </div>
  );
}

export default CareLogVitals;
