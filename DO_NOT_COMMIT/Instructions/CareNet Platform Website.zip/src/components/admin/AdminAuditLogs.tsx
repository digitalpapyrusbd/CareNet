import { Activity, Filter, Download, Search, ArrowLeft, User, FileText, Shield } from "lucide-react";
import { Button } from "../ui/button";
import { useState } from "react";

interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  userType: string;
  action: string;
  target: string;
  result: 'success' | 'failure';
  ip: string;
  device: string;
}

interface AdminAuditLogsProps {
  onExport?: () => void;
  onViewDetails?: (id: string) => void;
  onNavigate?: (page: string) => void;
}

export function AdminAuditLogs({
  onExport,
  onViewDetails,
  onNavigate
}: AdminAuditLogsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<string>("all");

  const auditLogs: AuditLog[] = [
    {
      id: "1",
      timestamp: "2025-01-26 14:23:45",
      user: "Fatima Khan",
      userType: "Moderator",
      action: "Approved Agency Verification",
      target: "Care Solutions Ltd",
      result: "success",
      ip: "103.92.xxx.xxx",
      device: "Chrome on Windows"
    },
    {
      id: "2",
      timestamp: "2025-01-26 14:15:30",
      user: "Admin Super",
      userType: "Admin",
      action: "Updated System Settings",
      target: "Commission Rate",
      result: "success",
      ip: "103.92.xxx.xxx",
      device: "Firefox on MacOS"
    },
    {
      id: "3",
      timestamp: "2025-01-26 13:45:12",
      user: "Rahim Ahmed",
      userType: "Moderator",
      action: "Rejected Caregiver Application",
      target: "ID: CG-2024-1234",
      result: "success",
      ip: "103.92.xxx.xxx",
      device: "Chrome on Android"
    },
    {
      id: "4",
      timestamp: "2025-01-26 12:30:00",
      user: "Unknown",
      userType: "System",
      action: "Failed Login Attempt",
      target: "admin@carenet.com",
      result: "failure",
      ip: "192.168.xxx.xxx",
      device: "Unknown"
    }
  ];

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.target.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterType === "all" || log.userType.toLowerCase() === filterType;
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen pb-6">
      <div className="p-6">
        {/* Back Button */}
        <button
          onClick={() => onNavigate?.('toc')}
          className="w-10 h-10 rounded-full flex items-center justify-center mb-4"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)' }}
        >
          <ArrowLeft className="w-5 h-5" style={{ color: '#535353' }} />
        </button>

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 style={{ color: '#535353' }}>Audit Logs</h1>
            <p style={{ color: '#848484' }}>System activity tracking</p>
          </div>
          <Button
            onClick={onExport}
            className="rounded-full px-4 py-2"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.6)',
              color: '#535353'
            }}
          >
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#848484' }} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search logs..."
            className="w-full pl-12 pr-4 py-3 rounded-xl outline-none"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.6)',
              color: '#535353',
              border: '1px solid rgba(255, 255, 255, 0.8)'
            }}
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {['all', 'admin', 'moderator', 'system'].map((filter) => (
            <button
              key={filter}
              onClick={() => setFilterType(filter)}
              className="px-4 py-2 rounded-full whitespace-nowrap transition-all"
              style={{
                backgroundColor: filterType === filter ? '#667eea' : 'rgba(255, 255, 255, 0.6)',
                color: filterType === filter ? 'white' : '#535353'
              }}
            >
              {filter.charAt(0).toUpperCase() + filter.slice(1)}
            </button>
          ))}
        </div>

        {/* Logs List */}
        <div className="space-y-3">
          {filteredLogs.map((log) => (
            <div 
              key={log.id} 
              className="finance-card p-4 cursor-pointer hover:shadow-lg transition-all"
              onClick={() => onViewDetails?.(log.id)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center"
                    style={{
                      background: log.result === 'success'
                        ? 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #A8E063 0%, #7CE577 100%)'
                        : 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FF6B6B 0%, #EE5A6F 100%)'
                    }}>
                    {log.userType === 'Admin' ? <Shield className="w-5 h-5 text-white" /> :
                     log.userType === 'Moderator' ? <User className="w-5 h-5 text-white" /> :
                     <Activity className="w-5 h-5 text-white" />}
                  </div>
                  <div>
                    <p style={{ color: '#535353' }}>{log.action}</p>
                    <p className="text-sm" style={{ color: '#848484' }}>by {log.user}</p>
                    <p className="text-xs mt-1" style={{ color: '#848484' }}>{log.timestamp}</p>
                  </div>
                </div>
                
                <span 
                  className="px-3 py-1 rounded-full text-xs"
                  style={{
                    backgroundColor: log.result === 'success' ? 'rgba(168, 224, 99, 0.2)' : 'rgba(255, 107, 107, 0.2)',
                    color: log.result === 'success' ? '#7CE577' : '#FF6B6B'
                  }}
                >
                  {log.result}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs" style={{ color: '#848484' }}>Target</p>
                  <p style={{ color: '#535353' }}>{log.target}</p>
                </div>
                <div>
                  <p className="text-xs" style={{ color: '#848484' }}>IP Address</p>
                  <p style={{ color: '#535353' }}>{log.ip}</p>
                </div>
              </div>

              <div className="mt-2 pt-2 border-t" style={{ borderColor: 'rgba(132, 132, 132, 0.1)' }}>
                <p className="text-xs" style={{ color: '#848484' }}>
                  {log.device}
                </p>
              </div>
            </div>
          ))}
        </div>

        {filteredLogs.length === 0 && (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 mx-auto mb-4" style={{ color: '#848484' }} />
            <p style={{ color: '#535353' }}>No audit logs found</p>
            <p className="text-sm mt-2" style={{ color: '#848484' }}>
              Try adjusting your search or filters
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
