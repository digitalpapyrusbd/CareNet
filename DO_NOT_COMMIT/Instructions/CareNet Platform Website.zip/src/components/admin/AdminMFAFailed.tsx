import { XCircle, RefreshCw, ArrowLeft } from "lucide-react";
import { Button } from "../ui/button";

interface AdminMFAFailedProps {
  attempts?: number;
  onRetry?: () => void;
  onBackToLogin?: () => void;
  onNavigate?: (page: string) => void;
}

export function AdminMFAFailed({
  attempts = 3,
  onRetry,
  onBackToLogin,
  onNavigate
}: AdminMFAFailedProps) {
  const maxAttempts = 5;
  const remainingAttempts = maxAttempts - attempts;
  const isLocked = remainingAttempts <= 0;

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <button
          onClick={() => onNavigate?.('toc')}
          className="w-10 h-10 rounded-full flex items-center justify-center mb-4"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)' }}
        >
          <ArrowLeft className="w-5 h-5" style={{ color: '#535353' }} />
        </button>

        <div className="finance-card p-8 text-center">
          {/* Error Icon */}
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #f44336 0%, #d32f2f 100%)' }}>
              <XCircle className="w-10 h-10 text-white" />
            </div>
          </div>

          <h1 className="mb-4" style={{ color: '#535353' }}>
            {isLocked ? "Account Locked" : "MFA Verification Failed"}
          </h1>

          {isLocked ? (
            <>
              <p className="mb-6" style={{ color: '#848484' }}>
                Your account has been temporarily locked due to multiple failed verification attempts.
              </p>
              
              <div className="p-4 rounded-xl mb-6" style={{ backgroundColor: 'rgba(244, 67, 54, 0.1)', border: '1px solid rgba(244, 67, 54, 0.3)' }}>
                <p style={{ color: '#535353' }}>
                  Please contact the system administrator or wait 30 minutes before trying again.
                </p>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={onBackToLogin}
                  className="w-full py-6 rounded-xl"
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.6)',
                    color: '#535353'
                  }}
                >
                  Back to Login
                </Button>
              </div>
            </>
          ) : (
            <>
              <p className="mb-6" style={{ color: '#848484' }}>
                The verification code you entered was incorrect.
              </p>

              {/* Attempts Warning */}
              <div className={`p-4 rounded-xl mb-6 ${remainingAttempts <= 2 ? 'animate-pulse' : ''}`} 
                style={{ 
                  backgroundColor: remainingAttempts <= 2 ? 'rgba(244, 67, 54, 0.1)' : 'rgba(255, 193, 7, 0.1)', 
                  border: `1px solid ${remainingAttempts <= 2 ? 'rgba(244, 67, 54, 0.3)' : 'rgba(255, 193, 7, 0.3)'}` 
                }}>
                <p style={{ color: '#535353' }}>
                  <span className="font-semibold">{remainingAttempts}</span> attempt{remainingAttempts !== 1 ? 's' : ''} remaining
                </p>
                {remainingAttempts <= 2 && (
                  <p className="mt-2 text-sm" style={{ color: '#848484' }}>
                    Your account will be locked after all attempts are exhausted
                  </p>
                )}
              </div>

              <div className="space-y-3">
                <Button
                  onClick={onRetry}
                  className="w-full py-6 rounded-xl text-white"
                  style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  }}
                >
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Try Again
                </Button>

                <Button
                  onClick={onBackToLogin}
                  className="w-full py-6 rounded-xl"
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.6)',
                    color: '#535353'
                  }}
                >
                  Back to Login
                </Button>
              </div>
            </>
          )}

          {/* Security Log Notice */}
          <p className="mt-6 text-sm" style={{ color: '#848484' }}>
            All authentication attempts are logged for security purposes
          </p>
        </div>
      </div>
    </div>
  );
}
