import { Lock, Shield, ArrowLeft } from "lucide-react";
import { Button } from "../ui/button";
import { useState } from "react";

interface AdminLoginProps {
  onLogin: (phone: string, password: string) => void;
  onNavigate?: (page: string) => void;
}

export function AdminLogin({ onLogin, onNavigate }: AdminLoginProps) {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Auto-login without validation - accept any input
    onLogin(phone || "admin", password || "admin");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <button
          onClick={() => onNavigate?.('toc')}
          className="w-10 h-10 rounded-full flex items-center justify-center mb-4"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)' }}
        >
          <ArrowLeft className="w-5 h-5" style={{ color: '#535353' }} />
        </button>

        {/* Login Form Card */}
        <div className="w-full max-w-md finance-card p-8">
          {/* Icon Header */}
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
              <Shield className="w-8 h-8 text-white" />
            </div>
          </div>

          <h1 className="text-center mb-2" style={{ color: '#535353' }}>Platform Admin Login</h1>
          <p className="text-center mb-8" style={{ color: '#848484' }}>Secure administrative access with MFA</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Phone Number */}
            <div>
              <label htmlFor="phone" className="block mb-2" style={{ color: '#535353' }}>
                Phone Number
              </label>
              <input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+880 1XXX-XXXXXX"
                className="w-full px-4 py-3 rounded-xl outline-none"
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.6)',
                  color: '#535353',
                  border: '1px solid rgba(255, 255, 255, 0.8)'
                }}
              />
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block mb-2" style={{ color: '#535353' }}>
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full px-4 py-3 rounded-xl outline-none pr-12"
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.6)',
                    color: '#535353',
                    border: '1px solid rgba(255, 255, 255, 0.8)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: '#848484' }}
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
            </div>

            {/* Security Notice */}
            <div className="p-4 rounded-xl" style={{ backgroundColor: 'rgba(255, 193, 7, 0.1)', border: '1px solid rgba(255, 193, 7, 0.3)' }}>
              <div className="flex gap-3">
                <Lock className="w-5 h-5 flex-shrink-0" style={{ color: '#ff9800' }} />
                <div>
                  <p style={{ color: '#535353' }}>
                    Admin login requires MFA verification for enhanced security
                  </p>
                </div>
              </div>
            </div>

            {/* Login Button */}
            <Button
              type="submit"
              className="w-full py-6 rounded-xl text-white"
              style={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
              }}
            >
              Continue to MFA
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
