import { ArrowLeft, Search, Filter, Star, CheckCircle, XCircle, Clock, Eye, ChevronDown, FileText, Video, Upload, Paperclip, Download, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { Button } from '../ui/button';

interface CaregiverInterviewQueueProps {
  onNavigate?: (page: string) => void;
}

interface InterviewCandidate {
  id: number;
  name: string;
  namebn: string;
  photo: string;
  applicationId: string;
  submittedDate: string;
  interviewDate: string;
  interviewType: 'video' | 'in-person';
  status: 'pending' | 'scheduled' | 'completed' | 'no-show';
  experience: string;
  rating?: number;
  previousSteps: {
    certificates: 'approved' | 'pending' | 'rejected';
    police: 'approved' | 'pending' | 'rejected';
  };
}

const MOCK_CANDIDATES: InterviewCandidate[] = [
  {
    id: 1,
    name: 'Fatima Rahman',
    namebn: 'ফাতিমা রহমান',
    photo: '👩‍⚕️',
    applicationId: 'CG-2024-1847',
    submittedDate: '2024-01-15',
    interviewDate: '2024-01-20 10:00 AM',
    interviewType: 'video',
    status: 'scheduled',
    experience: '5 years eldercare',
    previousSteps: {
      certificates: 'approved',
      police: 'approved'
    }
  },
  {
    id: 2,
    name: 'Ayesha Begum',
    namebn: 'আয়েশা বেগম',
    photo: '👩',
    applicationId: 'CG-2024-1856',
    submittedDate: '2024-01-16',
    interviewDate: '2024-01-21 2:00 PM',
    interviewType: 'in-person',
    status: 'pending',
    experience: '3 years pediatric care',
    previousSteps: {
      certificates: 'approved',
      police: 'approved'
    }
  },
  {
    id: 3,
    name: 'Sultana Khatun',
    namebn: 'সুলতানা খাতুন',
    photo: '👩‍🦱',
    applicationId: 'CG-2024-1863',
    submittedDate: '2024-01-17',
    interviewDate: '2024-01-19 11:30 AM',
    interviewType: 'video',
    status: 'completed',
    experience: '7 years disability care',
    rating: 4.5,
    previousSteps: {
      certificates: 'approved',
      police: 'approved'
    }
  }
];

export function CaregiverInterviewQueue({ onNavigate }: CaregiverInterviewQueueProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'scheduled' | 'completed'>('all');
  const [selectedCandidate, setSelectedCandidate] = useState<InterviewCandidate | null>(null);
  const [showEvaluation, setShowEvaluation] = useState(false);
  const [evaluationScores, setEvaluationScores] = useState({
    communication: 0,
    professionalism: 0,
    technicalKnowledge: 0,
    empathy: 0,
    reliability: 0
  });
  const [overallNotes, setOverallNotes] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<Array<{name: string, size: number, uploadedAt: string}>>([]);

  const filteredCandidates = MOCK_CANDIDATES.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         candidate.applicationId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || candidate.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return '#FFB020';
      case 'completed': return '#7CE577';
      case 'pending': return '#9B9CF8';
      case 'no-show': return '#FF6B6B';
      default: return '#848484';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'scheduled': return 'Scheduled';
      case 'completed': return 'Completed';
      case 'pending': return 'Pending';
      case 'no-show': return 'No Show';
      default: return status;
    }
  };

  const handleStartEvaluation = (candidate: InterviewCandidate) => {
    setSelectedCandidate(candidate);
    setShowEvaluation(true);
  };

  const handleScoreChange = (category: keyof typeof evaluationScores, score: number) => {
    setEvaluationScores(prev => ({
      ...prev,
      [category]: score
    }));
  };

  const calculateOverallScore = () => {
    const scores = Object.values(evaluationScores);
    const total = scores.reduce((sum, score) => sum + score, 0);
    return (total / scores.length).toFixed(1);
  };

  const handleSubmitEvaluation = (approved: boolean) => {
    // Validation: Check if evaluation form is uploaded
    if (uploadedFiles.length === 0) {
      alert('Please upload the completed evaluation form from the authorized evaluator before submitting.');
      return;
    }

    const overallScore = calculateOverallScore();
    alert(`Interview ${approved ? 'Approved' : 'Rejected'}\n\nCandidate: ${selectedCandidate?.name}\nOverall Score: ${overallScore}/5\nEvaluation Form: ${uploadedFiles[0].name}\n\nThis will move the candidate to ${approved ? 'the next verification step' : 'rejected status'}.`);
    setShowEvaluation(false);
    setSelectedCandidate(null);
    setEvaluationScores({
      communication: 0,
      professionalism: 0,
      technicalKnowledge: 0,
      empathy: 0,
      reliability: 0
    });
    setOverallNotes('');
    setUploadedFiles([]);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      
      // Validate file type
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedTypes.includes(file.type)) {
        alert('Please upload only PDF or image files (JPG, PNG)');
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
      }
      
      const newFile = {
        name: file.name,
        size: file.size,
        uploadedAt: new Date().toLocaleString()
      };
      
      setUploadedFiles([...uploadedFiles, newFile]);
    }
  };

  const handleRemoveFile = (index: number) => {
    setUploadedFiles(uploadedFiles.filter((_, i) => i !== index));
  };

  if (showEvaluation && selectedCandidate) {
    return (
      <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
        {/* Header */}
        <div className="sticky top-0 z-10 px-6 py-4" 
          style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
          <div className="flex items-center gap-4">
            <button onClick={() => setShowEvaluation(false)} className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="flex-1">
              <h1 className="text-white">Interview Evaluation</h1>
              <p className="text-white/80 text-sm">{selectedCandidate.applicationId}</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Candidate Info */}
          <div className="finance-card p-5">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FFB3C1 0%, #FF8FA3 100%)' }}>
                {selectedCandidate.photo}
              </div>
              <div className="flex-1">
                <h3 style={{ color: '#535353' }}>{selectedCandidate.name}</h3>
                <p className="text-sm" style={{ color: '#848484' }}>{selectedCandidate.namebn}</p>
                <p className="text-xs mt-1" style={{ color: '#9B9CF8' }}>{selectedCandidate.experience}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Video className="w-4 h-4" style={{ color: '#667eea' }} />
              <span style={{ color: '#848484' }}>{selectedCandidate.interviewDate}</span>
            </div>
          </div>

          {/* Evaluation Criteria */}
          <div className="finance-card p-5">
            <h3 className="mb-4" style={{ color: '#535353' }}>Evaluation Criteria</h3>
            
            {Object.entries(evaluationScores).map(([category, score]) => (
              <div key={category} className="mb-6 last:mb-0">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm capitalize" style={{ color: '#535353' }}>
                    {category.replace(/([A-Z])/g, ' $1').trim()}
                  </span>
                  <span className="text-sm" style={{ color: '#667eea' }}>
                    {score}/5
                  </span>
                </div>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((value) => (
                    <button
                      key={value}
                      onClick={() => handleScoreChange(category as keyof typeof evaluationScores, value)}
                      className="flex-1 py-2 rounded-lg transition-all"
                      style={{
                        background: score >= value 
                          ? 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FFB020 0%, #FF8FA3 100%)'
                          : 'rgba(155, 156, 248, 0.1)',
                        color: score >= value ? 'white' : '#848484'
                      }}
                    >
                      {value}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Overall Score */}
          <div className="finance-card p-5 text-center">
            <p className="text-sm mb-2" style={{ color: '#848484' }}>Overall Score</p>
            <div className="flex items-center justify-center gap-2">
              <Star className="w-8 h-8" style={{ color: '#FFB020', fill: '#FFB020' }} />
              <span className="text-3xl" style={{ color: '#535353' }}>{calculateOverallScore()}</span>
              <span className="text-xl" style={{ color: '#848484' }}>/5.0</span>
            </div>
          </div>

          {/* Evaluation Form Upload - Required */}
          <div className="finance-card p-5"
            style={{
              border: uploadedFiles.length === 0 ? '2px dashed #FF6B6B' : '2px solid #7CE577'
            }}>
            <div className="flex items-center gap-2 mb-3">
              <FileText className="w-5 h-5" style={{ color: uploadedFiles.length === 0 ? '#FF6B6B' : '#7CE577' }} />
              <h3 style={{ color: '#535353' }}>
                Authorized Evaluator Form 
                <span className="text-xs ml-2 px-2 py-1 rounded-full" 
                  style={{ 
                    background: 'rgba(255, 107, 107, 0.1)',
                    color: '#FF6B6B'
                  }}>
                  Required
                </span>
              </h3>
            </div>
            <p className="text-xs mb-4" style={{ color: '#848484' }}>
              Upload the completed evaluation form filled by an authorized interviewer. 
              Accepted formats: PDF, JPG, PNG (Max 5MB)
            </p>
            
            {/* File List */}
            {uploadedFiles.length > 0 && (
              <div className="space-y-2 mb-4">
                {uploadedFiles.map((file, index) => (
                  <div 
                    key={index} 
                    className="flex items-center gap-3 p-3 rounded-lg"
                    style={{ backgroundColor: 'rgba(124, 229, 119, 0.1)' }}
                  >
                    <Paperclip className="w-4 h-4" style={{ color: '#7CE577' }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm truncate" style={{ color: '#535353' }}>{file.name}</p>
                      <p className="text-xs" style={{ color: '#848484' }}>
                        {(file.size / 1024).toFixed(2)} KB • {file.uploadedAt}
                      </p>
                    </div>
                    <button
                      onClick={() => handleRemoveFile(index)}
                      className="p-2 rounded-lg hover:bg-red-50 transition-colors"
                      style={{ color: '#FF6B6B' }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Upload Button */}
            <input
              type="file"
              onChange={handleFileUpload}
              accept=".pdf,.jpg,.jpeg,.png"
              className="hidden"
              id="evaluation-form-upload"
            />
            <label
              htmlFor="evaluation-form-upload"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl cursor-pointer transition-all"
              style={{
                background: uploadedFiles.length === 0 
                  ? 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #667eea 0%, #764ba2 100%)'
                  : 'rgba(155, 156, 248, 0.1)',
                color: uploadedFiles.length === 0 ? 'white' : '#667eea'
              }}
            >
              <Upload className="w-5 h-5" />
              {uploadedFiles.length === 0 ? 'Upload Evaluation Form' : 'Upload Another File'}
            </label>
          </div>

          {/* Notes */}
          <div className="finance-card p-5">
            <label className="block text-sm mb-2" style={{ color: '#535353' }}>
              Interview Notes
            </label>
            <textarea
              value={overallNotes}
              onChange={(e) => setOverallNotes(e.target.value)}
              placeholder="Add detailed observations about the candidate's interview performance..."
              className="w-full p-4 rounded-xl border-0 resize-none"
              rows={6}
              style={{ 
                backgroundColor: 'rgba(155, 156, 248, 0.05)',
                color: '#535353'
              }}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={() => handleSubmitEvaluation(false)}
              className="flex-1 py-4"
              style={{
                background: 'rgba(255, 107, 107, 0.1)',
                color: '#FF6B6B'
              }}
            >
              <XCircle className="w-5 h-5 mr-2" />
              Reject
            </Button>
            <Button
              onClick={() => handleSubmitEvaluation(true)}
              className="flex-1 py-4"
              style={{
                background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #7CE577 0%, #4CAF50 100%)',
                color: 'white'
              }}
            >
              <CheckCircle className="w-5 h-5 mr-2" />
              Approve
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F5F7FA' }}>
      {/* Header */}
      <div className="sticky top-0 z-10 px-6 py-4" 
        style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => onNavigate?.('moderator-dashboard')} className="text-white">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-white">Interview Queue</h1>
            <p className="text-white/80 text-sm">Caregiver Verification - Step 3</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/60" />
          <input
            type="text"
            placeholder="Search by name or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl border-0 bg-white/20 text-white placeholder:text-white/60"
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-6 py-4 flex gap-2 overflow-x-auto">
        {(['all', 'pending', 'scheduled', 'completed'] as const).map((filter) => (
          <button
            key={filter}
            onClick={() => setFilterStatus(filter)}
            className="px-4 py-2 rounded-lg whitespace-nowrap transition-all"
            style={{
              background: filterStatus === filter 
                ? 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FFB3C1 0%, #FF8FA3 100%)'
                : 'white',
              color: filterStatus === filter ? 'white' : '#848484'
            }}
          >
            {filter === 'all' ? 'All' : filter.charAt(0).toUpperCase() + filter.slice(1)}
          </button>
        ))}
      </div>

      {/* Stats Cards */}
      <div className="px-6 mb-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="finance-card p-4 text-center">
            <div className="text-2xl mb-1" style={{ color: '#9B9CF8' }}>
              {MOCK_CANDIDATES.filter(c => c.status === 'pending').length}
            </div>
            <div className="text-xs" style={{ color: '#848484' }}>Pending</div>
          </div>
          <div className="finance-card p-4 text-center">
            <div className="text-2xl mb-1" style={{ color: '#FFB020' }}>
              {MOCK_CANDIDATES.filter(c => c.status === 'scheduled').length}
            </div>
            <div className="text-xs" style={{ color: '#848484' }}>Scheduled</div>
          </div>
          <div className="finance-card p-4 text-center">
            <div className="text-2xl mb-1" style={{ color: '#7CE577' }}>
              {MOCK_CANDIDATES.filter(c => c.status === 'completed').length}
            </div>
            <div className="text-xs" style={{ color: '#848484' }}>Completed</div>
          </div>
        </div>
      </div>

      {/* Candidate List */}
      <div className="px-6 space-y-3">
        {filteredCandidates.length === 0 ? (
          <div className="finance-card p-8 text-center">
            <Clock className="w-12 h-12 mx-auto mb-3" style={{ color: '#9B9CF8' }} />
            <p style={{ color: '#848484' }}>No candidates found</p>
          </div>
        ) : (
          filteredCandidates.map((candidate) => (
            <div key={candidate.id} className="finance-card p-5">
              <div className="flex items-start gap-4 mb-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                  style={{ background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #FFB3C1 0%, #FF8FA3 100%)' }}>
                  {candidate.photo}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="truncate" style={{ color: '#535353' }}>{candidate.name}</h3>
                  <p className="text-sm truncate" style={{ color: '#848484' }}>{candidate.namebn}</p>
                  <p className="text-xs mt-1" style={{ color: '#9B9CF8' }}>{candidate.applicationId}</p>
                </div>
                <div className="px-3 py-1 rounded-full text-xs whitespace-nowrap"
                  style={{ 
                    background: `${getStatusColor(candidate.status)}20`,
                    color: getStatusColor(candidate.status)
                  }}>
                  {getStatusLabel(candidate.status)}
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Video className="w-4 h-4" style={{ color: '#667eea' }} />
                  <span style={{ color: '#848484' }}>
                    {candidate.interviewType === 'video' ? 'Video Call' : 'In-Person'} • {candidate.interviewDate}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <FileText className="w-4 h-4" style={{ color: '#7CE577' }} />
                  <span style={{ color: '#848484' }}>{candidate.experience}</span>
                </div>
                {candidate.rating && (
                  <div className="flex items-center gap-2 text-sm">
                    <Star className="w-4 h-4" style={{ color: '#FFB020', fill: '#FFB020' }} />
                    <span style={{ color: '#535353' }}>{candidate.rating}/5.0</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 mb-4 text-xs">
                <span style={{ color: '#848484' }}>Previous:</span>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" style={{ color: '#7CE577' }} />
                  <span style={{ color: '#848484' }}>Certificates</span>
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" style={{ color: '#7CE577' }} />
                  <span style={{ color: '#848484' }}>Police Check</span>
                </div>
              </div>

              {candidate.status === 'scheduled' && (
                <Button
                  onClick={() => handleStartEvaluation(candidate)}
                  className="w-full py-3"
                  style={{
                    background: 'radial-gradient(143.86% 887.35% at -10.97% -22.81%, #667eea 0%, #764ba2 100%)',
                    color: 'white'
                  }}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Start Evaluation
                </Button>
              )}

              {candidate.status === 'completed' && (
                <Button
                  onClick={() => handleStartEvaluation(candidate)}
                  className="w-full py-3"
                  style={{
                    background: 'rgba(155, 156, 248, 0.1)',
                    color: '#667eea'
                  }}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  View Evaluation
                </Button>
              )}

              {candidate.status === 'pending' && (
                <Button
                  className="w-full py-3"
                  style={{
                    background: 'rgba(255, 176, 32, 0.1)',
                    color: '#FFB020'
                  }}
                >
                  <Clock className="w-4 h-4 mr-2" />
                  Schedule Interview
                </Button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}