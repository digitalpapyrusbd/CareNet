# CareNet Billing Flow Diagram

## 💰 Complete Financial Transaction Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    CARENET PLATFORM BILLING                      │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│              │         │              │         │              │
│  CAREGIVER   │         │    AGENCY    │         │   GUARDIAN   │
│              │         │              │         │              │
└──────┬───────┘         └──────┬───────┘         └──────┬───────┘
       │                        │                        │
       │                        │                        │
       │    ① Invoice for       │                        │
       │    completed work      │                        │
       ├───────────────────────>│                        │
       │    (Hours × Wage)      │                        │
       │                        │                        │
       │                        │    ② Invoice for       │
       │                        │    service             │
       │                        ├───────────────────────>│
       │                        │    (Package Price)     │
       │                        │                        │
       │                        │                        │
       │        ③ Platform      │       ③ Platform       │  ③ Platform
       │        Subscription    │       Subscription     │  Subscription
       │        + Commission    │       + Commission     │  (Optional)
       │                        │                        │
       │         ↓              │         ↓              │      ↓
       │         │              │         │              │      │
       └─────────┼──────────────┼─────────┼──────────────┼──────┘
                 │              │         │              │
                 │              │         │              │
                 └──────────────┴─────────┴──────────────┘
                                 │
                                 ↓
                    ┌────────────────────────┐
                    │   CARENET PLATFORM     │
                    │                        │
                    │  Collects:             │
                    │  • Subscriptions       │
                    │  • Commissions         │
                    └────────────────────────┘
```

---

## 📊 Billing Breakdown by Entity

### **CAREGIVER Billing Dashboard**

```
┌─────────────────────────────────────────────────────────┐
│  CAREGIVER BILLING                                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  OUTGOING (What I Invoice)                             │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 📤 Generate Invoice to Agency                     │ │
│  │    ├─ Job: [Job Name]                             │ │
│  │    ├─ Hours Worked: XX hrs                        │ │
│  │    ├─ Wage Rate: $XX/hr                           │ │
│  │    └─ Total: $XXX.XX                              │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  INCOMING (What I Pay)                                 │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 💳 Platform Invoice                               │ │
│  │    ├─ Subscription Fee: $XX.XX                    │ │
│  │    ├─ Commission (X%): $X.XX                      │ │
│  │    └─ Total Due: $XXX.XX                          │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

### **AGENCY Billing Dashboard**

```
┌─────────────────────────────────────────────────────────┐
│  AGENCY BILLING                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  OUTGOING (What I Invoice)                             │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 📤 Generate Invoice to Guardian                   │ │
│  │    ├─ Package: [Package Name]                     │ │
│  │    ├─ Duration: X days/weeks                      │ │
│  │    ├─ Package Price: $XXX.XX                      │ │
│  │    ├─ Discount: -$XX.XX (if negotiated)           │ │
│  │    └─ Total: $XXX.XX                              │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  INCOMING (Costs)                                      │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 📥 Caregiver Invoices (To Review & Pay)           │ │
│  │    ├─ Caregiver 1: $XXX.XX                        │ │
│  │    ├─ Caregiver 2: $XXX.XX                        │ │
│  │    └─ Total: $XXX.XX                              │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 💳 Platform Invoice                               │ │
│  │    ├─ Subscription Fee: $XXX.XX                   │ │
│  │    ├─ Transaction Commission (X%): $XX.XX         │ │
│  │    └─ Total Due: $XXXX.XX                         │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  PROFIT MARGIN                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │ Guardian Payment: +$1,000                         │ │
│  │ Caregiver Costs: -$600                            │ │
│  │ Platform Fees: -$150                              │ │
│  │ ═══════════════════════                           │ │
│  │ NET PROFIT: $250                                  │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

### **GUARDIAN Billing Dashboard**

```
┌─────────────────────────────────────────────────────────┐
│  GUARDIAN BILLING                                       │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  INCOMING (What I Pay)                                 │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 📥 Agency Service Invoices                        │ │
│  │    ├─ Agency: [Agency Name]                       │ │
│  │    ├─ Package: [Package Name]                     │ │
│  │    ├─ Service Period: [Dates]                     │ │
│  │    └─ Total Due: $XXX.XX                          │ │
│  │    └─ [Pay via bKash/Nagad]                       │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │ 💳 Platform Subscription (Optional)               │ │
│  │    ├─ Subscription Plan: [Premium]                │ │
│  │    ├─ Period: Monthly/Yearly                      │ │
│  │    └─ Total Due: $XX.XX                           │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 🔄 Complete Transaction Example

### **Scenario:** Guardian purchases 30-day care package

```
┌──────────────────────────────────────────────────────┐
│  DAY 1: PACKAGE PURCHASE                             │
└──────────────────────────────────────────────────────┘

GUARDIAN pays AGENCY: $1,000
                      ↓
              Package becomes JOB
                      ↓
         AGENCY deploys CAREGIVER

┌──────────────────────────────────────────────────────┐
│  DAY 1-30: SERVICE DELIVERY                          │
└──────────────────────────────────────────────────────┘

CAREGIVER works 30 days
Logs care activities daily
Agency monitors via platform

┌──────────────────────────────────────────────────────┐
│  DAY 30: JOB COMPLETION & BILLING                    │
└──────────────────────────────────────────────────────┘

Step 1: CAREGIVER → AGENCY
├─ Caregiver generates invoice
├─ 30 days × 8 hours × $25/hr = $6,000
├─ Agency reviews and approves
└─ Agency pays Caregiver: $6,000

Step 2: AGENCY → GUARDIAN  
├─ Agency generates invoice (already paid upfront)
├─ Or bills for additional services: $200
└─ Guardian pays if additional: $200

Step 3: PLATFORM → ALL ENTITIES

PLATFORM → CAREGIVER:
├─ Subscription: $29/month
├─ Commission (5% of earnings): $300
└─ Caregiver pays Platform: $329

PLATFORM → AGENCY:
├─ Subscription: $199/month
├─ Transaction Commission (10%): $1,000
└─ Agency pays Platform: $1,199

PLATFORM → GUARDIAN (Optional):
├─ Premium Subscription: $9.99/month
└─ Guardian pays Platform: $9.99

┌──────────────────────────────────────────────────────┐
│  FINAL FINANCIAL SUMMARY                             │
└──────────────────────────────────────────────────────┘

CAREGIVER:
  Earned: $6,000
  Paid Platform: -$329
  NET: $5,671

AGENCY:
  Received from Guardian: $1,200
  Paid Caregiver: -$6,000
  Paid Platform: -$1,199
  NET: -$5,999 (Loss - pricing error scenario!)
  
  ⚠️ Agency should price packages to cover costs!
  
GUARDIAN:
  Paid Agency: $1,200
  Paid Platform: -$9.99
  TOTAL COST: $1,209.99

PLATFORM:
  From Caregiver: $329
  From Agency: $1,199
  From Guardian: $9.99
  REVENUE: $1,537.99
```

---

## 🎯 Billing Workflow Status Indicators

### **Invoice States:**

```
┌─────────────┐
│   DRAFT     │  → Invoice being prepared
└─────────────┘

┌─────────────┐
│   SENT      │  → Invoice sent to recipient
└─────────────┘

┌─────────────┐
│  PENDING    │  → Awaiting payment
└─────────────┘

┌─────────────┐
│   PAID      │  → Payment received
└─────────────┘

┌─────────────┐
│  OVERDUE    │  → Past due date
└─────────────┘

┌─────────────┐
│  DISPUTED   │  → Under review
└─────────────┘
```

---

## 📱 Payment Methods Integration

```
┌───────────────────────────────────────────┐
│         PAYMENT GATEWAY OPTIONS           │
├───────────────────────────────────────────┤
│                                           │
│  📱 bKash                                 │
│     └─ Mobile Financial Service           │
│        └─ Most popular in Bangladesh      │
│                                           │
│  📱 Nagad                                 │
│     └─ Government-backed MFS              │
│        └─ Alternative to bKash            │
│                                           │
│  💳 Credit/Debit Cards                    │
│     └─ International payments             │
│        └─ Backup option                   │
│                                           │
└───────────────────────────────────────────┘
```

---

## 🔐 Billing Security & Compliance

### **Data Protection:**
- ✅ Encrypted payment processing
- ✅ PCI DSS compliance for card payments
- ✅ Secure storage of financial records
- ✅ GDPR-compliant data handling

### **Audit Trail:**
- ✅ Complete transaction history
- ✅ Admin oversight of all billing
- ✅ Automatic record keeping
- ✅ Financial reporting for compliance

### **Dispute Resolution:**
- ✅ Invoice dispute workflow
- ✅ Moderator first-line review
- ✅ Admin final decision
- ✅ Refund processing capability

---

## 📈 Revenue Analytics Dashboard (Admin View)

```
┌─────────────────────────────────────────────────────┐
│  PLATFORM REVENUE DASHBOARD                         │
├─────────────────────────────────────────────────────┤
│                                                     │
│  MONTHLY RECURRING REVENUE (MRR)                    │
│  ┌───────────────────────────────────────────────┐ │
│  │ Caregiver Subscriptions: $X,XXX               │ │
│  │ Agency Subscriptions: $XX,XXX                 │ │
│  │ Guardian Subscriptions: $X,XXX                │ │
│  │ TOTAL MRR: $XX,XXX                            │ │
│  └───────────────────────────────────────────────┘ │
│                                                     │
│  TRANSACTION REVENUE                                │
│  ┌───────────────────────────────────────────────┐ │
│  │ Caregiver Commissions: $X,XXX                 │ │
│  │ Agency Commissions: $XX,XXX                   │ │
│  │ TOTAL COMMISSION: $XX,XXX                     │ │
│  └───────────────────────────────────────────────┘ │
│                                                     │
│  TOTAL MONTHLY REVENUE: $XXX,XXX                    │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## ✅ Billing System Features Summary

### **Automated:**
- ✅ Invoice generation based on job completion
- ✅ Commission calculation
- ✅ Payment reminders
- ✅ Receipt generation

### **Manual:**
- ✅ Invoice review and approval (agencies reviewing caregiver invoices)
- ✅ Dispute resolution
- ✅ Refund processing
- ✅ Custom invoice adjustments

### **Reporting:**
- ✅ Financial dashboards
- ✅ Revenue analytics
- ✅ Payment history
- ✅ Tax reports
- ✅ Profit/loss statements

---

## 🚀 Future Enhancements

1. **Multi-currency Support** - International transactions
2. **Cryptocurrency Payments** - Modern payment options
3. **Automated Tax Calculation** - VAT/GST integration
4. **Bulk Payment Processing** - Payroll for agencies
5. **Invoice Customization** - Branded invoices
6. **Subscription Management** - Auto-renewal, upgrades/downgrades
7. **Financial Forecasting** - Predictive analytics
8. **Expense Tracking** - Business expense management
9. **Integration with Accounting Software** - QuickBooks, Xero
10. **Payment Plans** - Installment options for large packages
