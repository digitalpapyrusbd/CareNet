import React from 'react';

export function Legend() {
  return (
    <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-6 max-w-md">
      <h3 className="text-gray-900 mb-4">Legend</h3>
      
      <div className="space-y-4">
        {/* Node Types */}
        <div>
          <h4 className="text-sm text-gray-700 mb-2">Node Types</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-20 h-8 rounded-full bg-gray-400 flex items-center justify-center text-white text-xs">
                Start/End
              </div>
              <span className="text-gray-600">Start/End Point</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-20 h-12 bg-blue-200 border-2 border-blue-500 rounded flex items-center justify-center text-xs">
                Action
              </div>
              <span className="text-gray-600">User Action</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-20 h-12 bg-green-200 border-2 border-green-600 rounded flex items-center justify-center text-xs">
                Process
              </div>
              <span className="text-gray-600">System Process</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 bg-yellow-200 border-2 border-orange-500 transform rotate-45 flex items-center justify-center">
                <span className="text-xs transform -rotate-45">?</span>
              </div>
              <span className="text-gray-600">Decision Point</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-20 h-12 bg-purple-200 border-4 border-purple-600 border-double rounded flex items-center justify-center text-xs">
                External
              </div>
              <span className="text-gray-600">External Service</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-16 h-12 bg-teal-100 border-2 border-teal-500" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                <div className="flex items-center justify-center h-full text-xs">🤖</div>
              </div>
              <span className="text-gray-600">AI Agent</span>
            </div>
          </div>
        </div>

        {/* Connector Types */}
        <div className="pt-4 border-t border-gray-200">
          <h4 className="text-sm text-gray-700 mb-2">Flow Types</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-16 h-0.5 bg-gray-800"></div>
              <span className="text-gray-600">Normal Flow</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-16 h-0.5 border-t-2 border-dashed border-orange-500"></div>
              <span className="text-gray-600">Conditional</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-16 h-0.5 border-t-2 border-dotted border-blue-500"></div>
              <span className="text-gray-600">Data Flow</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-16 h-0.5 border-t-2 border-dashed border-red-500"></div>
              <span className="text-gray-600">Error Path</span>
            </div>
          </div>
        </div>

        {/* Color Key */}
        <div className="pt-4 border-t border-gray-200">
          <h4 className="text-sm text-gray-700 mb-2">Swimlane Colors</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#E8DAEF' }}></div>
              <span className="text-gray-600">Admin</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#D4E6F1' }}></div>
              <span className="text-gray-600">Agency</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#D5F5E3' }}></div>
              <span className="text-gray-600">Caregiver</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#FDEBD0' }}></div>
              <span className="text-gray-600">Guardian</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#D1F2EB' }}></div>
              <span className="text-gray-600">Shop</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
